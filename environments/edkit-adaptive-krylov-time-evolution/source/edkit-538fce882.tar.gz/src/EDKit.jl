"""
    EDKit

Julia package for exact diagonalization, symmetry-resolved basis construction,
many-body operator assembly, entanglement diagnostics, selected ITensor
conversions, and open-system or quadratic-fermion workflows.

The package is organized around a small number of central abstractions:
- basis objects describe state spaces and symmetry sectors,
- [`Operator`](@ref) stores many-body operators as sums of local terms,
- conversion helpers move between vectors, matrices, MPS/MPO objects, and
  symmetry-adapted coordinates.

Most functionality is implemented in subsystem files under `src/Basis`,
`src/ITensors`, and `src/algorithms`, but all public names are re-exported
through this top-level module.
"""
module EDKit

using LinearAlgebra, SparseArrays, Random, Combinatorics
using ITensors, ITensorMPS, LRUCache

import Base: +, -, *, /, Array, Vector, Matrix, size, length, eltype, digits, copy
import LinearAlgebra: norm, mul!

include("Basis/AbstractBasis.jl")
include("Basis/ProjectedBasis.jl")
include("Basis/TranslationalBasis.jl")
include("Basis/TranslationalParityBasis.jl")
include("Basis/TranslationalFlipBasis.jl")
include("Basis/ParityBasis.jl")
include("Basis/FlipBasis.jl")
include("Basis/ParityFlipBasis.jl")
include("Basis/AbelianBasis.jl")


include("LinearMap.jl")
include("Schmidt.jl")
include("Operator.jl")
include("ToolKit.jl")

for file in sort(readdir("$(@__DIR__)/algorithms/"))
    if file[end-2:end] == ".jl"
        include("$(@__DIR__)/algorithms/$file")
    end
end

for file in sort(readdir("$(@__DIR__)/ITensors/"))
    if file[end-2:end] == ".jl"
        include("$(@__DIR__)/ITensors/$file")
    end
end

end # module
