
#include <exception>
#include "NEST.hh"
#include <stdexcept>
#include <mutex>

#define ZurichEXOW 1.1716263232
#define ZurichEXOQ \
  1.08  // Qy Boost Factor to fit EXO-200 Data (error on this quantity is +/-
        // 0.03)
//#define InfraredNR 7.

#define ChargeLoss 1.000  // 0.77 is LUX Run03 default (wall BG model)

using namespace std;
using namespace NEST;

static constexpr int podLength = 1100;  // roughly 100-1,000 ns for S1 in LXe, 5000 - roughly 6-11us for LAr
static constexpr double McMConst = 0.0; //NR Nq pow law +const
bool kr83m_reported_low_deltaT = false;  // to aid in verbosity

NESTresult NESTcalc::FullCalculation(INTERACTION_TYPE species, double energy,
                                     double density, double dfield, double A,
                                     double Z,
                                     const std::vector<double> &NRYieldsParam,
                                     const std::vector<double> &NRERWidthsParam,
                                     const std::vector<double> &ERYieldsParam,
                                     bool do_times /*=true*/) {
  if (density < 1.) fdetector->set_inGas(true);
  NESTresult result;
  result.yields = GetYields(species, energy, density, dfield, A, Z,
                            NRYieldsParam, ERYieldsParam);
  result.quanta =
      GetQuanta(result.yields, density, NRERWidthsParam, -999.);
  if (do_times)
    result.photon_times = GetPhotonTimes(
        species, result.quanta.photons, result.quanta.excitons, dfield, energy);
  else {
    result.photon_times = photonstream(result.quanta.photons, 0.0);
  }
  return result;
}

double NESTcalc::PhotonTime(INTERACTION_TYPE species, bool exciton,
    double dfield, double energy, double tripERavg, double tripERerr) {
  double time_ns = 0., SingTripRatio = 0., tauR = 0.,
    tau3 = RandomGen::rndm()->rand_gauss(24.,1.,true),  // error from weighted average
    tau1 = RandomGen::rndm()->rand_gauss(3.1,.7,true);  // ibid.
  if (fdetector->get_inGas() || energy < W_DEFAULT * 0.001) {
    // from G4S1Light.cc in old NEST
    tau1 = 5.18;   // uncertainty of 1.55 ns from G4S2Light
    tau3 = 100.1;  // uncertainty of 7.90 ns from G4S2Light
  }
  // tau1 = 3.5*ns; tau3 = 20.*ns; tauR = 40.*ns for solid Xe from old NEST.
  // Here assuming same as in liquid

  // if ( dfield > 60. ) dfield = 60. // makes Xed work. 200 for LUX Run04
  // instead. A mystery! Why no field dep?

  double LET = CalcElectronLET(energy, ATOM_NUM);
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // copied from 2013 NEST version for LAr on LBNE
    tau1 = RandomGen::rndm()->rand_gauss(6, 0.8,
                                         true);  // error from weighted average
    tau3 = RandomGen::rndm()->rand_gauss(1500, 50, true);  // ibid.
    tauR = 0;
    if (species <= Cf) {
      SingTripRatio =(0.50124402-0.005939726*exp(-dfield/0.10912019))*pow(energy,0.30214913+0.04352277*exp(-dfield/27.56144196));
      }
    else if (species == ion) {  // really only alphas here
      SingTripRatio = (-0.065492 + 1.9996 * exp(-energy / 1e3)) /
                          (1. + 0.082154 / pow(energy / 1e3, 2.)) +
                      2.1811;  // uses energy in MeV not keV
    } else {
      SingTripRatio =(0.89642*pow(energy,-0.317989) + 0.000107*pow(energy, 1.13426));
    }  // lastly is ER for LAr
  } else {
    if (species <= Cf) {  // NR
      tau3 = RandomGen::rndm()->rand_gauss(23.97,0.17,true); //arXiv:1802.06162
      tau1 = RandomGen::rndm()->rand_gauss( 3.27,0.66,true); //arXiv:1802.06162
      SingTripRatio = 0.269; if (exciton) tauR = 0.5;
    }
    else if (species == ion) {
      // e.g., alphas
      SingTripRatio =
          0.065 *
          pow(energy,
              0.416);  // spans 2.3 (alpha) and 7.8 (Cf in Xe) from NEST v1
    } else {  // ER
      tau3 = RandomGen::rndm()->rand_gauss(tripERavg,tripERerr,true);//1802.06162
      tau1 = RandomGen::rndm()->rand_gauss(3.27,0.66,true); //arXiv:1802.06162
      if (!exciton) {
        if (energy > 1e3)
          energy = 1e3;  // MIP above ~1 MeV. Fix thanks to Austin de St. Croix
        tauR = exp(-0.00900 * dfield) *
               (7.3138 + 3.8431 * log10(energy));  // arXiv:1310.1117
        //if (tauR < 3.5) tauR = 3.5;  // gammas?
        if (dfield > 8e2) dfield = 8e2;  // to match Kubota's 4,000 V/cm
        SingTripRatio = 0.042;
      } else {
        SingTripRatio = 0.042; tauR = 0.;
      }
    }
  }
  if (fdetector->get_inGas() || energy < W_DEFAULT * 0.001) {
    SingTripRatio = 0.1;
    if (fdetector->get_inGas() && !exciton)
      tauR = 28e3;
    else {
      tauR = 0.;  // 28 microseconds comes from Henrique:
                  // https://doi.org/10.1016/j.astropartphys.2018.04.006
    }
    if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
      tau3 = 1600.;
      tau1 = 6.;
    }  // from old G4S2Light
  }
  if (tauR < 0.) tauR = 0.;  // in case varied with Gaussian earlier

  // the recombination time is non-exponential, but approximates
  // to exp at long timescales (see Kubota '79)
   time_ns += tauR * (1.0 / RandomGen::rndm()->rand_uniform() - 1.);

  if (RandomGen::rndm()->rand_uniform() < SingTripRatio / (1. + SingTripRatio))
    time_ns -= tau1 * log(RandomGen::rndm()->rand_uniform());
  else {
    time_ns -= tau3 * log(RandomGen::rndm()->rand_uniform());
  }
  if (time_ns<0) time_ns=0; return time_ns;
}

// in analytical model, an empirical distribution (Brian Lenardo and Dev A.K.)
photonstream NESTcalc::AddPhotonTransportTime(const photonstream &emitted_times,
                                              double x, double y, double z) {
  photonstream return_photons;
  for (auto t : emitted_times) {
    double newtime = t + fdetector->OptTrans(x, y, z);
    return_photons.emplace_back(newtime);
  }
  return return_photons;
}

photonstream NESTcalc::GetPhotonTimes(INTERACTION_TYPE species,
                                      int total_photons, int excitons,
                                      double dfield, double energy) {
  photonstream return_photons;
  int total, excit;
	
  if (excitons > total_photons) {
    throw std::runtime_error("You specified more excitons than total photon number?! This is physically wrong, so please check your inputs.");
  }
	
  for (int ip = 0; ip < total_photons; ++ip) {
    bool isExciton = false;
    if (ip < excitons) isExciton = true;
    // message from Matthew: please stop telling me next line bad. I can't skip
    // PhotonTime, it's a func not array
    return_photons.emplace_back(PhotonTime(species, isExciton, dfield, energy));
  }

  return return_photons;
}

double NESTcalc::RecombOmegaNR(double elecFrac,
                               const std::vector<double> &NRERWidthsParam) {
  double omega =
      NRERWidthsParam[2] * exp(-0.5 * pow(elecFrac - NRERWidthsParam[3], 2.) /
                               (NRERWidthsParam[4] * NRERWidthsParam[4]));
  if (omega < 0.) omega = 0;
  return omega;
}

double NESTcalc::RecombOmegaER(double efield, double elecFrac, double numQuanta,
                               const std::vector<double> &NRERWidthsParam) {
  double ampl;
  ampl = 0.07 + (NRERWidthsParam[7] - 0.07) /
    pow(1. + pow(efield / 295.2, 251.6), 0.0069114);
  // NRERWidthsParam[7] sets the lower-asymptote of field-dependence of ampl
  if (ampl < 0.) ampl = 0.;
  double cntr = NRERWidthsParam[8];  // Center of omega vs. elec-frac
  double wide = NRERWidthsParam[9];  // Width of omega vs. electron-fraction
                                     // (i.e. recomb. prob.)
  if ( wide > cntr ) {
    //throw std::runtime_error("Low-E r-fluct Gauss peak's width greater than centroid. This is physically wrong so please check your inputs, in NRERWidthsParam: they must be in the old wrong order.");
    static std::once_flag wrong_order_print_statement;  // Temporary workaround to accept current (incorrect) Skin model in LZLAMA.
    std::call_once(wrong_order_print_statement, []() {
            cerr << "Low-E r-fluct Gauss peak's width greater than centroid. This is physically wrong so please check your inputs, in NRERWidthsParam: they must be in the old wrong order." << endl;
        });
  }
  double skew =
      NRERWidthsParam[10]; // Skewness of omega vs. elec-frac distribution
  double mode = cntr + 2. * inv_sqrt2_PI * skew * wide / sqrt(1. + skew * skew);
  double norm =
      1. / (exp(-0.5 * pow(mode - cntr, 2.) / (wide * wide)) *
            (1. + erf(skew * (mode - cntr) /
                      (wide * sqrt2))));  // makes sure omega never exceeds ampl
  double omega;
  if ( cntr < 1. )
    omega = norm * ampl *
                 exp(-0.5 * pow(elecFrac - cntr, 2.) / (wide * wide)) *
                 (1. + erf(skew * (elecFrac - cntr) / (wide * sqrt2)));
  else
  {
    // Double Gaussian default parameters
    double ampl2 = 0.06103; // up to 0.1
    double cntr2 = 5.207; // ~4-5
    double wide2 = 1.361; // ~0.5-1
    double skew2 = -2.495; // up to 0.0
    
    // Check if parameters have been passed
    if (NRERWidthsParam.size() > 15) {
      ampl2 = NRERWidthsParam[13];
      cntr2 = NRERWidthsParam[14];
      wide2 = NRERWidthsParam[15];
    }
    // Check is skew 
    if (NRERWidthsParam.size() > 16) skew2 = NRERWidthsParam[16];
    
    double mode2 = cntr2 + 2. * inv_sqrt2_PI * skew2 * wide2 / sqrt(1. + skew2 * skew2);
    double logNQ = log10(numQuanta);
    double norm2 = 1. / (exp(-0.5 * pow(mode2 - cntr2, 2.) / (wide2 * wide2)) * (1. + erf(skew2 * (mode2 - cntr2) / (wide2 * sqrt2))));
    omega = 0.00 +
      norm * ampl * exp(-0.5 * pow(logNQ - cntr, 2.) / (wide * wide)) *
      (1. + erf(skew * (logNQ - cntr) / (wide * sqrt2))) +
      norm2 * ampl2 * exp(-0.5 * pow(logNQ - cntr2, 2.) / (wide2 * wide2)) *
      (1. + erf(skew2 * (logNQ - cntr2) / (wide2 * sqrt2)));
  }
  if (omega < 0.) omega = 0;
  return omega;
}

double NESTcalc::FanoER(double density, double Nq_mean, double efield,
                        const std::vector<double> &NRERWidthsParam) {
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.))  // liquid argon
    return 0.1115;  // T&I. conflicting reports of .107 (Doke) & ~0.1 elsewhere
  double Fano =
      0.12707 - 0.029623 * density -  // Fano factor is  << 1
      0.0057042 *
          pow(density,
              2.) +  //~0.1 for GXe w/ formula from Bolotnikov et al. 1995
      0.0015957 *
          pow(density,
              3.);  // to get it to be ~0.03 for LXe (E Dahl Ph.D. thesis)
  if (!fdetector->get_inGas()) {
    if (NRERWidthsParam[6] < 0.)
      Fano += fabs(NRERWidthsParam[6]) * sqrt(Nq_mean) * pow(efield, 0.5);
    else
      Fano = NRERWidthsParam[6];
  }
  return Fano;
}

QuantaResult NESTcalc::GetQuanta(const YieldResult &yields, double density,
                                 const std::vector<double> &NRERWidthsParam,
                                 double SkewnessER) {
  QuantaResult result{};
  bool HighE;
  int Nq_actual, Ne, Nph, Ni, Nex;

  if (NRERWidthsParam.size() < 13) {
    throw std::runtime_error(
        "ERROR: You need a minimum of 13 free parameters for the resolution "
        "model.");
  }

  double excitonRatio = yields.ExcitonRatio;
  double Nq_mean = yields.PhotonYield + yields.ElectronYield;

  double elecFrac = max(0., min(yields.ElectronYield / Nq_mean, 1.));

  if (excitonRatio < 0.) {
    excitonRatio = 0.;
    HighE = true;
  } else {
    HighE = false;
  }
  
  double alf = 1. / (1. + excitonRatio);
  double recombProb = 1. - (excitonRatio + 1.) * elecFrac;
  if (recombProb < 0.) {
    excitonRatio = 1. / elecFrac - 1.;
  }
  
  if (ValidityTests::nearlyEqual(yields.Lindhard, 1.)) {
    if (ValidityTests::nearlyEqual(Nq_mean, 0.))
      Nq_actual = 0;
    else {
      double Fano =
          FanoER(density, Nq_mean, yields.ElectricField, NRERWidthsParam);
      Nq_actual = int(floor(
          RandomGen::rndm()->rand_gauss(Nq_mean, sqrt(Fano * Nq_mean), true) +
          0.5));
    }

    Ni = RandomGen::rndm()->binom_draw(Nq_actual, alf);
    Nex = Nq_actual - Ni;

  } else {
    double Ni_mean = Nq_mean * alf;
    double Fano = NRERWidthsParam[0] + NRERWidthsParam[11] * Ni_mean;
    // non-constant F_i (negative or positive slope possible).
    // Based on work of James Verbus (LUX Run03 DD) and Matthew
    if ( Fano < 0. ) Fano = 0.;
    Ni = int(floor(RandomGen::rndm()->rand_gauss(
                       Ni_mean, sqrt(Fano * Ni_mean), true) +
                   0.5));
    double Nex_mean = Nq_mean * excitonRatio * alf;
    Fano = NRERWidthsParam[1] + NRERWidthsParam[12] * Nex_mean;
    // non-constant F_ex (positive or negative slope possible).
    // Based on work of Chen Ding (LZ SR1 D-D Migdal)
    if ( Fano < 0. ) Fano = 0.;
    Nex = int(floor(RandomGen::rndm()->rand_gauss(
                        Nex_mean,
                        sqrt(Fano * Nex_mean), true) +
                    0.5));
    Nq_actual = Nex + Ni;
  }

  if (Nq_actual == 0) {
    result.ions = 0;
    result.excitons = 0;
    result.photons = 0;
    result.electrons = 0;
    result.Variance = 0;
    result.recombProb = 0;
    return result;
  }

  if (Nex < 0) Nex = 0;
  if (Ni < 0) Ni = 0;
  if (Nex > Nq_actual) Nex = Nq_actual;
  if (Ni > Nq_actual) Ni = Nq_actual;

  result.ions = Ni;
  result.excitons = Nex;

  if (Nex <= 0 && HighE) recombProb = yields.PhotonYield / double(Ni);
  recombProb = max(0., min(recombProb, 1.));
  if (std::isnan(recombProb) || std::isnan(elecFrac) || Ni == 0 ||
      ValidityTests::nearlyEqual(recombProb, 0.0)) {
    result.photons = Nex;
    result.electrons = Ni;
    elecFrac = 1.0;
    result.recombProb = 0.;
    result.Variance = 0.;
    return result;
  }

  // set omega (non-binomial recombination fluctuations parameter) according to
  // whether the Lindhard <1, i.e. this is NR.
  double omega = yields.Lindhard < 1
                     ? RecombOmegaNR(elecFrac, NRERWidthsParam)
                     : RecombOmegaER(yields.ElectricField, elecFrac, Nq_mean
                                     , NRERWidthsParam);
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.))
    omega = 0.0;  // Ar has no non-binom sauce
  double lambdaChen; if ( NRERWidthsParam[2] < 0. && yields.Lindhard < 1 ) lambdaChen = 1.0 + NRERWidthsParam[2];
  else lambdaChen = 1.0; if ( lambdaChen <= 0. ) lambdaChen = 1E-6;
  double Variance = lambdaChen * // Binomial recombination suppressant -- from Chen Ding's Migdal work (Brown U.)
    recombProb * (1. - recombProb) * Ni + omega * omega * Ni * Ni;
  if ( lambdaChen != 1. && omega != 0. ) cerr << "CAUTION - Contradictory recomb fluct parameter values" << endl;
  // if ( !fdetector->get_OldW13eV() ) Variance /= sqrt ( ZurichEXOQ );

  double skewness;
  if ((yields.PhotonYield + yields.ElectronYield) > 1e4 ||
      yields.ElectricField > 4e3 || yields.ElectricField < 50.) {
    skewness = 0.00;  // make it a constant 0 when outside the range of Vetri
                      // Velan's Run04 models.
  } else {
    // LUX Skewness Model
    Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                                 fdetector->get_OldW13eV());
    double Wq_eV = wvalue.Wq_eV;
    double engy = 1e-3 * Wq_eV * (yields.PhotonYield + yields.ElectronYield);
    double fld = yields.ElectricField;

    double alpha0 = 1.39;
    double cc0 = 4.0, cc1 = 22.1;
    double E0 = 7.7, E1 = 54., E2 = 26.7, E3 = 6.4;
    double F0 = 225., F1 = 71.;

    skewness = 0.;

    if (ValidityTests::nearlyEqual(yields.Lindhard, 1.)) {
      if (SkewnessER != -999.) {
        skewness = SkewnessER;
      } else {
        skewness = 1. / (1. + exp((engy - E2) / E3)) *
                       (alpha0 + cc0 * exp(-1. * fld / F0) *
                                     (1. - exp(-1. * engy / E0))) +
                   1. / (1. + exp(-1. * (engy - E2) / E3)) * cc1 *
                       exp(-1. * engy / E1) * exp(-1. * sqrt(fld) / sqrt(F1));
      }

      // if ( std::abs(skewness) <= DBL_MIN ) skewness = DBL_MIN;
    } else {
      skewness = NRERWidthsParam[5];  // 2.25 but ~5-20 also good (for NR). All
                                      // better than zero, but 0 is OK too
    }  // note to self: find way to make 0 for ion (wall BG) incl. alphas?
  }

  double widthCorrection =
      sqrt(1. - (2. / M_PI) * skewness * skewness / (1. + skewness * skewness));
  double muCorrection = (sqrt(Variance) / widthCorrection) *
                        (skewness / sqrt(1. + skewness * skewness)) * 2. *
                        inv_sqrt2_PI;
  if (std::abs(skewness) > DBL_MIN &&
      ValidityTests::nearlyEqual(ATOM_NUM,
                                 54.))  // skewness model only for Xenon!
    Ne = int(floor(RandomGen::rndm()->rand_skewGauss(
                       (1. - recombProb) * Ni - muCorrection,
                       sqrt(Variance) / widthCorrection, skewness) +
                   0.5));
  else {
    Ne = int(floor(RandomGen::rndm()->rand_gauss((1. - recombProb) * Ni,
                                                 sqrt(Variance), true) +
                   0.5));
  }

  Ne = NESTcalc::clamp(Ne, 0, Ni);

  Nph = Nq_actual - Ne;
  if (Nph > Nq_actual) Nph = Nq_actual;
  if (Nph < Nex) Nph = Nex;

  if ((Nph + Ne) != (Nex + Ni)) {
    throw std::runtime_error(
        "ERROR: Quanta not conserved. Tell Matthew Immediately!");
  }

  result.Variance = Variance;
  result.recombProb = recombProb;
  result.photons = Nph;
  result.electrons = Ne;

  return result;  // quanta returned with recomb fluctuations
}

YieldResult NESTcalc::GetYieldGamma(double energy, double density,
                                    double dfield, double multFact) {
  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double Wq_eV = wvalue.Wq_eV;
  double alpha = wvalue.alpha;
  constexpr double m3 = 2., m4 = 2., m6 = 0.;

  const double m1 =
      33.951 + (3.3284 - 33.951) / (1. + pow(dfield / 165.34, .72665));
  double m2 = 1000 / Wq_eV;
  double m5 = 23.156 + (10.737 - 23.156) / (1. + pow(dfield / 34.195, .87459));
  double densCorr = 240720. / pow(density, 8.2076);
  double m7 =
      66.825 + (829.25 - 66.825) / (1. + pow(dfield / densCorr, .83344));

  double Nq = energy * 1000. / Wq_eV;
  double m8 = 2.;
  if (fdetector->get_inGas()) m8 = -2.;
  double Qy = m1 + (m2 - m1) / (1. + pow(energy / m3, m4)) + m5 +
              (m6 - m5) / (1. + pow(energy / m7, m8));
  if (!fdetector->get_OldW13eV()) Qy *= ZurichEXOQ;
  Qy *= multFact;
  double Ly = Nq / energy - Qy;

  YieldResult result{};
  result.PhotonYield = Ly * energy;
  result.ElectronYield = Qy * energy;
  result.ExcitonRatio = NexONi(energy, density);
  result.Lindhard = 1;
  result.ElectricField = dfield;
  result.DeltaT_Scint = -999;
  return YieldResultValidity(result, energy, Wq_eV);
}

YieldResult NESTcalc::GetYieldERWeighted(
    double energy, double density, double dfield,
    const std::vector<double> &ERYieldsParam,
    const std::vector<double> &EnergyParams,
    const std::vector<double> &FieldParams) {
  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double Wq_eV = wvalue.Wq_eV;

  YieldResult yieldsB = GetYieldBetaGR(energy, density, dfield, ERYieldsParam);
  YieldResult yieldsG = GetYieldGamma(energy, density, dfield);
  double weightG =
      EnergyParams[0] +
      EnergyParams[1] * erf(EnergyParams[2] * (log(energy) + EnergyParams[3])) *
          (1. - (1. / (1. + pow(dfield / FieldParams[0], FieldParams[1]))));
  // field weighting added to match dependence reported by XELDA and LUX Run3.
  // Not validated beyond of fields on the order of a few hundred V/cm
  double weightB = 1. - weightG;

  YieldResult result{};
  result.PhotonYield =
      weightG * yieldsG.PhotonYield + weightB * yieldsB.PhotonYield;
  result.ElectronYield =
      weightG * yieldsG.ElectronYield + weightB * yieldsB.ElectronYield;
  result.ExcitonRatio =
      weightG * yieldsG.ExcitonRatio + weightB * yieldsB.ExcitonRatio;
  result.Lindhard = weightG * yieldsG.Lindhard + weightB * yieldsB.Lindhard;
  result.ElectricField =
      weightG * yieldsG.ElectricField + weightB * yieldsB.ElectricField;
  result.DeltaT_Scint =
      weightG * yieldsG.DeltaT_Scint + weightB * yieldsB.DeltaT_Scint;
  return YieldResultValidity(result, energy, Wq_eV);
}

NESTresult NESTcalc::GetYieldERdEOdxBasis(
    const std::vector<double> &dEOdxParam, string muonInitPos,
    vector<double> vTable, const std::vector<double> &NRERWidthsParam) {
  Wvalue wvalue = WorkFunction(dEOdxParam[8], fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double Wq_eV = wvalue.Wq_eV;
  double rho = dEOdxParam[8];
  double xi = -999., yi = -999., zi = fdetector->get_TopDrift();
  double xf, yf, zf, pos_x, pos_y, pos_z, r, phi, field,
      eMin = dEOdxParam[4], z_step = dEOdxParam[5], inField = dEOdxParam[6];
  if (ValidityTests::nearlyEqual(eMin, 0.) || std::isnan(eMin))
    throw std::runtime_error("Energy cannot be zero or undefined");
  NESTresult result{};
  xf = dEOdxParam[0];
  yf = dEOdxParam[1];
  zf = dEOdxParam[2];
  if (ValidityTests::nearlyEqual(dEOdxParam[3], -1.)) {
    if (NRERWidthsParam[0] < 0. && eMin < 0.) {
      xi = xf - 10.;
      yi = yf;
      zi = zf;
    } else {
      r = fdetector->get_radmax() * sqrt(RandomGen::rndm()->rand_uniform());
      phi = 2. * M_PI * RandomGen::rndm()->rand_uniform();
      xi = r * cos(phi);
      yi = r * sin(phi);
    }
  } else {
    string position = muonInitPos;
    string delimiter = ",";
    size_t loc = 0;
    int ii = 0;
    while ((loc = position.find(delimiter)) != string::npos) {
      string token = position.substr(0, loc);
      if (ii == 0)
        xi = stof(token);
      else
        yi = stof(token);
      position.erase(0, loc + delimiter.length());
      ++ii;
    }
    zi = stof(position);
  }
  if (zi <= 0.) zi = fdetector->get_TopDrift();
  double dEOdx, eStep, refEnergy;
  if (eMin < 0.) {
    refEnergy = -eMin;
    if (dEOdxParam[10] > 0. && dEOdxParam[11] != 0.) {
      dEOdx = dEOdxParam[10] * pow(-eMin, dEOdxParam[11]);
      if (dEOdxParam[12] > 0.)
	; //do nothing yet. Old attempts: Gaussian, Expo, Poisson
    } else
      dEOdx = CalcElectronLET(-eMin, ATOM_NUM, dEOdxParam[10]);
    eStep = rho * z_step * 1e2 * RandomGen::rndm()->rand_zero_trunc_gauss(dEOdx,dEOdx);
  } else {
    refEnergy = dEOdxParam[9];
    eStep = eMin * rho * z_step * 1e2;
  }
  double driftTime, vD, keV = 0., Nq_mean;
  int Nph = 0, Ne = 0, Nq = 0;
  double xx = xi, yy = yi, zz = zi;
  if (zf < 0.) zf = 0.;
  double distance = sqrt((xf - xi) * (xf - xi) + (yf - yi) * (yf - yi) +
                         (zf - zi) * (zf - zi));
  double norm[3];
  double xi_tib;
  norm[0] = (xf - xi) / distance;
  norm[1] = (yf - yi) / distance;
  norm[2] = (zf - zi) / distance;
  bool stopCond = false;
  while (!stopCond &&
         (xx * xx + yy * yy) <
             fdetector->get_radmax() * fdetector->get_radmax() &&
         std::abs(refEnergy) > PHE_MIN) {
    if (((zf < zi && zz <= zf) || (zf > zi && zz >= zf)) &&
        ((xx - xf) * (xx - xf) + (yy - yf) * (yy - yf)) <
            4. * z_step * z_step) {
      stopCond = true;
      break;
    }
    // stop making S1 and S2 if particle exits Xe volume, OR runs out of
    // energy (in case of beta)
    if (inField == -1.)
      field = fdetector->FitEF(xx, yy, zz);
    else
      field = inField;
    if (eMin < 0.) {
      if ((keV + eStep) > -eMin) eStep = -eMin - keV;
      if (NRERWidthsParam[0] < 0.) {
        YieldResult yields{};
        Nq_mean = -NRERWidthsParam[0] * eStep;
        double Ni_mean = Nq_mean / (1. + NRERWidthsParam[1]);
        xi_tib = Ni_mean * (NRERWidthsParam[3] / 4.) *
                 pow(eStep, NRERWidthsParam[4] - 1.);
        yields.PhotonYield =
            Ni_mean * (1. + NRERWidthsParam[1] -
                       log(NRERWidthsParam[2] + xi_tib) / xi_tib);
        yields.ElectronYield = Nq_mean - yields.PhotonYield;
        yields.ExcitonRatio = NRERWidthsParam[1];
        yields.Lindhard = 1.;
        yields.ElectricField = field;
        yields.DeltaT_Scint = -999;
        result.yields = yields;
      } else
        result.yields = GetYieldBetaGR(eStep, rho, field);
    } else {
      result.yields = GetYieldBetaGR(refEnergy, rho, field);
    }
    if (eMin < 0. && NRERWidthsParam[0] < 0.) {
      QuantaResult quanta{};
      if (Nq_mean < 1.)
        Nq = 0;
      else //int(ceil(RandomGen::rndm()->rand_gauss(Nq_mean,sqrt(NRERWidthsParam[5]*Nq_mean),true)-0.5))
        Nq = RandomGen::rndm()->binom_draw(NRERWidthsParam[5]*eStep,Nq_mean/(NRERWidthsParam[5]*eStep));
      quanta.recombProb = 1. - log(NRERWidthsParam[2] + xi_tib) / xi_tib;
      if (result.yields.PhotonYield < 1. || Nq <= 0)
        quanta.photons = 0;
      else //int(ceil(RandomGen::rndm()->rand_gauss(result.yields.PhotonYield,sqrt(NRERWidthsParam[6]*result.yields.PhotonYield),true)-0.5))
        quanta.photons = RandomGen::rndm()->binom_draw(Nq,result.yields.PhotonYield/double(Nq));
      quanta.electrons = Nq - quanta.photons;
      quanta.ions = int(ceil(double(Nq) / (1. + NRERWidthsParam[1]) - 0.5));
      quanta.excitons = Nq - quanta.ions;
      quanta.recombProb = 1. - log(NRERWidthsParam[2] + xi_tib) / xi_tib;
      quanta.Variance = NRERWidthsParam[6] * result.yields.PhotonYield;
      result.quanta = quanta;
      Ne += result.quanta.electrons;
    } else
      result.quanta =
          GetQuanta(result.yields, rho, default_NRERWidthsParam, -999.);
    if (eMin > 0.)
      Nph += result.quanta.photons * (eStep / refEnergy);
    else {
      if (NRERWidthsParam[0] >= 0.) {
        Nq = result.quanta.photons + result.quanta.electrons;
        double FanoOverall =
            1.;  // use 6 for ~0.7% energy resolution at 2.6 MeV and 190 V/cm
        double FanoScint =
            200.;  // standin for recombination fluctuations in this approach
        Nq = int(floor(
            RandomGen::rndm()->rand_gauss(Nq, sqrt(FanoOverall * Nq), false) +
            0.5));
        result.quanta.photons =
            int(floor(RandomGen::rndm()->rand_gauss(
                          result.quanta.photons,
                          sqrt(FanoScint * result.quanta.photons), false) +
                      0.5));
        result.quanta.electrons = Nq - result.quanta.photons;
      }
      Nph += result.quanta.photons;
    }
    int index = int(floor(zz / z_step + 0.5));
    if (index >= vTable.size()) index = vTable.size() - 1;
    if (vTable.size() == 0)
      vD = dEOdxParam[7];
    else
      vD = vTable[index];
    driftTime = (fdetector->get_TopDrift() - zz) / vD;
    if (zz >= fdetector->get_cathode() && NRERWidthsParam[0] >= 0.) {
      if (eMin > 0.)
        Ne += result.quanta.electrons *
              exp(-driftTime / fdetector->get_eLife_us()) * (eStep / refEnergy);
      else
        Ne += result.quanta.electrons *
              exp(-driftTime / fdetector->get_eLife_us());
    }
    keV += eStep;
    xx += norm[0] * z_step;
    yy += norm[1] * z_step;
    zz += norm[2] * z_step;
    if (eMin < 0.) {
      refEnergy -= eStep;
      if (dEOdxParam[10] > 0. && dEOdxParam[11] != 0.) {
        dEOdx = dEOdxParam[10] * pow(refEnergy, dEOdxParam[11]);
        if (dEOdxParam[12] > 0.)
          dEOdx = RandomGen::rndm()->rand_gauss(dEOdx, dEOdxParam[12] * dEOdx,
                                                true);
      } else
        dEOdx = CalcElectronLET(refEnergy, ATOM_NUM, dEOdxParam[10]);
      eStep = dEOdx * rho * z_step * 1e2;
    }
    // cerr << keV << "\t\t" << xx << "\t" << yy << "\t" << zz << "\t" << Nph <<
    // "\t" << Ne << endl;
  }
  if (Nph < 0) Nph = 0;
  if (Ne < 0) Ne = 0;
  result.quanta.photons = Nph;
  result.quanta.electrons = Ne;
  pos_x =
      0.5 * (xi + xx);  // approximate things not already done right in loop as
  // middle of detector since muon traverses whole length
  pos_y = 0.5 * (yi + yy);
  pos_z = 0.5 * (zi + zz);
  if (inField == -1.)
    field = fdetector->FitEF(pos_x, pos_y, pos_z);
  else
    field = inField;
  result.yields.DeltaT_Scint = pos_z;
  result.yields.ElectricField = field;
  return result;
}

YieldResult NESTcalc::GetYieldNROld(
    double energy,
    int option) {  // possible anti-correlation in NR ignored totally

  double Ne, Nph, FakeField;

  if (option == 0) {
    // with old-school L_eff*S_nr conversion, and more explicit Thomas-Imel box
    // model formulae but approximation where Qy can sail off as energy to 0
    FakeField = 1.00;
    Nph = 0.95 * 64. * energy *
          (0.050295 * pow(energy, 1.3483) *
           (log(1. + (0.84074 * pow(energy, 1.3875))) /
            (0.84074 *
             pow(energy,
                 1.3875))));  // NESTv0.97beta (2011) ~0 V/cm arXiv:1106.1613
    Ne = energy * (10.661 * pow(energy, 0.16199) *
                       (log(1. + (0.745330 * pow(energy, 1.0880))) /
                        (0.745330 * pow(energy, 1.0880))) +
                   0.93739);  // essentially Lindhard with k of 0.166
  } else if (option == 1) {
    FakeField = 200.;
    Ne = energy *
         (4.1395 * pow(energy, 0.13816) *
          (log(1. + (0.040945 * pow(energy, 1.1388))) /
           (0.040945 *
            pow(energy,
                1.1388))));  // conservative: k < or ~ to 0.110 (Hitachi-like)
    Nph = energy * 3.35 *
          pow(energy,
              0.29222);  // NESTv0.98 (2013) model for legacy comparisons
                         // (arXiv:1307.6601) using simple power law (optional
                         // constant; optional for Nph)
  } else if (option == 2) {
    FakeField = 730.;
    Nph = 7582.3 +
          (-1.3728 - 7582.3) /
              (1. + pow(energy / 385.46,
                        1.2669));  // NEST v1.0 (2015) arXiv:1412.4417, with
                                   // ability to cut off yield at either low or
                                   // high energy. Fit to Nph
    Ne = (60.914 * pow(energy, 0.32220)) *
         (1. -
          exp(-0.12684 * pow(energy,
                             0.65729)));  // middle of road: k = 0.14. By Brian
                                          // Lenardo, still pre-LUX-DD. With
                                          // explicit bi-Exc quenching
  } else {
    // simplest by far, but not 1st principles: based on work of M. Wyman
    // UAlbany
    FakeField = 180.;  // fit to LUX Run03 D-D alone
    Ne = (-3.8780 + 12.372 * pow(energy, 0.73502)) *
         exp(-0.0034329 *
             energy);  // slide 68 of Matthew's private Google Slides mega-deck
    Nph = 0.81704 + 3.8584 * pow(energy, 1.30180);  // ditto
  }

  YieldResult result{};
  if (Nph < 0.) Nph = 0.;
  if (Ne < 0.) Ne = 0.;
  result.PhotonYield = Nph;
  result.ElectronYield = Ne;
  result.ExcitonRatio = 1.;
  result.Lindhard = ((Nph + Ne) / energy) * W_DEFAULT * 1e-3;
  result.ElectricField = FakeField;
  result.DeltaT_Scint = -999.;
  return YieldResultValidity(result, energy, W_DEFAULT);
}

YieldResult NESTcalc::GetYieldNR(double energy, double density, double dfield,
                                 double massNum,
                                 const std::vector<double> &NRYieldsParam) {
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.))
    massNum = fdetector->get_molarMass();

  if (NRYieldsParam.size() < 12) {
    throw std::runtime_error(
        "ERROR: You need a minimum of 12 nuisance parameters for the mean "
        "yields.");
  }
  if (energy > HIGH_E_NR)
    cerr << "\nWARNING: No data out here, you are beyond the AmBe endpoint of "
            "about 300 keV.\n";
  int massNumber;
  double ScaleFactor[2] = {1., 1.};
  if (ValidityTests::nearlyEqual(massNum, 0.))
    massNumber = RandomGen::rndm()->SelectRanXeAtom();
  else {
    massNumber = int(massNum);
  }
  ScaleFactor[0] = sqrt(fdetector->get_molarMass() / (double)massNumber);
  ScaleFactor[1] = ScaleFactor[0];
  double Nq = NRYieldsParam[0] * pow(energy, NRYieldsParam[1]) + McMConst;
  if (!fdetector->get_OldW13eV() && ValidityTests::nearlyEqual(ATOM_NUM, 54.)) Nq *= ZurichEXOW;
  double ThomasImel = NRYieldsParam[2] * pow(dfield, NRYieldsParam[3]) *
                      pow(density / DENSITY, 0.3);
                      
  double p = NRYieldsParam[9];  
  if (NRYieldsParam.size() >= 15) {
    const double a = NRYieldsParam[12];
    const double b = NRYieldsParam[13];
    const double E0 = NRYieldsParam[14];

    if (energy > E0) {
      p = 0.5 + a * log(1. + b * (energy - E0));
    } else {
      p = 0.5;
    }
  }
  double Qy =
      1. / (ThomasImel * pow(energy + NRYieldsParam[4], p));

  Qy *= 1. - 1. / pow(1. + pow((energy / NRYieldsParam[5]), NRYieldsParam[6]),
                      NRYieldsParam[10]);
                      
  if (!fdetector->get_OldW13eV()) Qy *= ZurichEXOQ;
  double Ly = Nq / energy - Qy;
  if (Qy < 0.0) Qy = 0.0;
  if (Ly < 0.0) Ly = 0.0;
  double Ne = Qy * energy * ScaleFactor[1];
  double Nph =
      Ly * energy * ScaleFactor[0];
  if (McMConst == 0.0) {
  	Nph *= (1. - 1. / pow(1. + pow((energy / NRYieldsParam[7]), NRYieldsParam[8]), NRYieldsParam[11]));
  }
  Nq = Nph + Ne;
  double Ni = (4. / ThomasImel) * (exp(Ne * ThomasImel / 4.) - 1.);
  double Nex = (-1. / ThomasImel) *
               (4. * exp(Ne * ThomasImel / 4.) - (Ne + Nph) * ThomasImel - 4.);

  double NexONi = Nex / Ni;
  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  if (NexONi < wvalue.alpha && energy > 1e2) {
    NexONi = wvalue.alpha;
    Ni = Nq / (1. + NexONi);
    Nex = Nq - Ni;
  }
  if (NexONi > 1.0 && energy < 1.) {
    NexONi = 1.00;
    Ni = Nq / (1. + NexONi);
    Nex = Nq - Ni;
  }

  if (Nex < 0. && density >= 1.)
    cerr << "\nCAUTION: You are approaching the border of NEST's validity for "
            "high-energy (OR, for LOW) NR, or are beyond it, at "
         << energy << " keV." << endl;
  if (std::abs(Nex + Ni - Nq) > 2. * PHE_MIN) {
    throw std::runtime_error(
        "ERROR: Quanta not conserved. Tell Matthew Immediately!");
  }

  double Wq_eV = wvalue.Wq_eV;
  double L = (Nq / energy) * Wq_eV * 1e-3;

  YieldResult result{};
  result.PhotonYield = Nph;
  result.ElectronYield = Ne;
  result.ExcitonRatio = NexONi;
  result.Lindhard = L;
  result.ElectricField = dfield;
  result.DeltaT_Scint = -999;
  return YieldResultValidity(
      result, energy, Wq_eV);  // everything needed to calculate fluctuations
}

YieldResult NESTcalc::GetYieldIon(
    double energy, double density, double dfield, double massNum,
    double atomNum,
    const std::vector<double>
        &NRYieldsParam) {  // simply uses the original Lindhard model, but as
                           // cited by Hitachi in:
  // https://indico.cern.ch/event/573069/sessions/230063/attachments/1439101/2214448/Hitachi_XeSAT2017_DM.pdf

  double A1 = massNum, A2 = RandomGen::rndm()->SelectRanXeAtom();
  double Z1 = atomNum, Z2 = ATOM_NUM;
  double Z_mean = pow(pow(Z1, (2. / 3.)) + pow(Z2, (2. / 3.)), 1.5);
  double E1c = pow(A1, 3.) * pow(A1 + A2, -2.) * pow(Z_mean, (4. / 3.)) *
               pow(Z1, (-1. / 3.)) * 500.;
  double E2c = pow(A1 + A2, 2.) * pow(A1, -1.) * Z2 * 125.;
  double gamma = 4. * A1 * A2 / pow(A1 + A2, 2.);
  double Ec_eV = gamma * E2c;
  double Constant = (2. / 3.) * (1. / sqrt(E1c) + 0.5 * sqrt(gamma / Ec_eV));
  double L = Constant * sqrt(energy * 1e3);
  double L_max = 0.96446 / (1. + pow(massNum * massNum / 19227., 0.99199));
  if (ValidityTests::nearlyEqual(atomNum, 2.) &&
      ValidityTests::nearlyEqual(massNum, 4.))
    L = 0.56136 * pow(energy, 0.056972);
  if (L > L_max) L = L_max;
  double densDep = pow(density / 0.2679, -2.3245);
  double massDep =
      0.02966094 * exp(0.17687876 * (massNum / 4. - 1.)) + 1. - 0.02966094;
  double fieldDep = 0.095*pow(dfield,0.515)-0.025; if ( fieldDep < 0. ) fieldDep = 0.;
  if (fdetector->get_inGas()) fieldDep = sqrt(dfield);
  double eneDep = 0.13 - 0.0013 * energy; if ( eneDep < 0. ) eneDep = 0.;
  double ThomasImel = 0.00625 * massDep / (1. + densDep) / fieldDep + eneDep;
  double alpha = 0.64 / pow(1. + pow(density / 10., 2.), 449.61);
  double NexONi = alpha + 0.00178 * pow(atomNum, 1.587);
  if (ValidityTests::nearlyEqual(A1, 206.) &&
      ValidityTests::nearlyEqual(Z1,
                                 82.)) {  // Pb-206 (from Po-210 alpha decay).
    ThomasImel =
        exp(-1.28683 - 1.42053e-03 * dfield);  // updated by Nishat Parveen
    NexONi = 1.1;                              // updated by Nishat Parveen
  }
  const double logden = log10(density);
  double Wq_eV = 28.259 + 25.667 * logden - 33.611 * pow(logden, 2.) -
                 123.73 * pow(logden, 3.) - 136.47 * pow(logden, 4.) -
                 74.194 * pow(logden, 5.) - 20.276 * pow(logden, 6.) -
                 2.2352 * pow(logden, 7.);
  double Nq = 1e3 * L * energy / Wq_eV;
  if (!fdetector->get_OldW13eV()) Nq *= ZurichEXOW;
  double Ni = Nq / (1. + NexONi);
  double recombProb;
  if (Ni > 0. && ThomasImel > 0.)
    recombProb =
        1. - log(1. + (ThomasImel / 4.) * Ni) / ((ThomasImel / 4.) * Ni);
  else {
    recombProb = 0.0;
  }
  double Nph = Nq * NexONi / (1. + NexONi) + recombProb * Ni;
  double Ne = Nq - Nph;
  if (ValidityTests::nearlyEqual(A1, 206.) &&
      ValidityTests::nearlyEqual(Z1, 82.))
    Ne = RandomGen::rndm()->binom_draw(Ne, ChargeLoss);
  // some electrons from lead recoils get absorbed by the Teflon wall
  if (ValidityTests::nearlyEqual(Z2, 18.) &&
      ValidityTests::nearlyEqual(Z1, 2.) &&
      ValidityTests::nearlyEqual(A1, 4.)) {  // alphas in argon
    double factorE = pow((4.71598 + pow(dfield, 7.72848)), 0.109802);
    double Qy = (1. / 6200.) *
                (64478398.7663 -
                 (64478398.7663 * 0.173553719 +
                  (64478398.7663 / 1.21) *
                      (1. - (0.02852 * log(1. + (64478398.7663 / 1.21) *
                                                    ((0.01 / factorE) / 3.))) /
                                ((64478398.7663 / 1.21) * (0.01 / factorE)))));
    double qu = 1. / (1.16 * pow(dfield, -0.012));
    factorE = pow(4.98483 + pow(dfield / 10.0822, 1.2076), 0.97977);
    double Ly =
        qu * (1. / 6500.) *
        (278037.250283 * 0.173553719 +
         (278037.250283 / 1.21) *
             (1. - (2. * log(1. + (278037.250283 / 1.21) *
                                      ((0.653503 / factorE) / 3.))) /
                       ((278037.250283 / 1.21) * (0.653503 / factorE))));
    Ne = Qy * energy;
    Nph = Ly * energy;
    L = 1.0;//actually isn't used, because L is "included" in formulae themselves, just to prevent YieldResultsValidity to trigger
    NexONi = 0.21;
    Wq_eV = 19.5;
  }

  YieldResult result{};
  result.PhotonYield = Nph;
  result.ElectronYield = Ne;
  result.ExcitonRatio = NexONi;
  result.Lindhard = L;
  result.ElectricField = dfield;
  result.DeltaT_Scint = -999;
  return YieldResultValidity(
      result, energy, Wq_eV);  // everything needed to calculate fluctuations
}

YieldResult NESTcalc::GetYieldKr83m(double energy, double density,
                                    double dfield, double maxTimeSeparation,
                                    double minTimeSeparation) {
  if (minTimeSeparation > maxTimeSeparation &&
      (energy < 32.0 || energy >= 32.2))
    throw std::runtime_error("ERROR: min greater than max");

  double Nq = -999;
  double Nph = -999;
  double Ne = -999;
  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double Wq_eV = wvalue.Wq_eV;
  double alpha = wvalue.alpha;
  constexpr double deltaT_ns_halflife = 154.4;
  YieldResult result{};
  double deltaT_ns = -999.;
  if (ValidityTests::nearlyEqual(minTimeSeparation, maxTimeSeparation))
    deltaT_ns = maxTimeSeparation;
  /*if (minTimeSeparation < 100. && energy < 32. &&
      kr83m_reported_low_deltaT == false) {
    kr83m_reported_low_deltaT = true;
    cerr << "\tWARNING! Outside of Kr83m model fit validity region. Details:"
         << " minTimeSeparation is < 100 ns and your input E is 9.4 keV."
         << " Data for separated Kr83m decays do not yet exist for deltaT_ns "
            "<100 ns."
         << " 9.4 & 32.1 keV yields are still summed to physically accurate "
            "result, but individually will be nonsensical."
         << endl;
  }*/

  if (!ValidityTests::nearlyEqual(minTimeSeparation, maxTimeSeparation))
    deltaT_ns = RandomGen::rndm()->rand_exponential(
        deltaT_ns_halflife, minTimeSeparation, maxTimeSeparation);
  double Nq_9 = 9.4e3 / Wq_eV;  // 9.4 keV model
  double a1 = -19.575;          //-11.839 + 78.063 / deltaT_ns;
  if (a1 > 0.) a1 = 0.;
  double a2 = 5.823e-4;  //(0.0015796*deltaT_ns)/(11.55+deltaT_ns);
  double a3 = 69.986 + 3e5 / pow(deltaT_ns, 2.);  // 2.7745e5 and 2
  if (a3 > 87.) a3 = 87.;
  double Nph_9 = 9.4 * (a1 * a2 * dfield * log(1. + 1. / (a2 * dfield)) + a3);
  double Ne_9 = Nq_9 - Nph_9;
  if (Ne_9 < 0.) Ne_9 = 0.;  // can't have negative charge, from either decay
  result = GetYieldGamma(2., density, dfield);
  double Nph_2 = result.PhotonYield;
  double Ne_2 = result.ElectronYield;
  result = GetYieldGamma(10., density, dfield);
  double Nph_10 = result.PhotonYield;
  double Ne_10 = result.ElectronYield;
  result = GetYieldGamma(12., density, dfield);
  double Nph_12 = result.PhotonYield;
  double Ne_12 = result.ElectronYield;
  result = GetYieldGamma(18., density, dfield);
  double Nph_18 = result.PhotonYield;
  double Ne_18 = result.ElectronYield;
  result = GetYieldGamma(30., density, dfield);
  double Nph_30 = result.PhotonYield;
  double Ne_30 = result.ElectronYield;
  double Nph_76 = Nph_30 + Nph_2;
  double Nph_09 = Nph_18 + Nph_10 + Nph_2 + Nph_2;
  double Nph_15 = Nph_18 + Nph_12 + Nph_2;
  // now, add up the 32.1 keV yields
  double Nph_32 = 0.76 * Nph_76 + 0.15 * Nph_15 + 0.09 * Nph_09;
  double Ne_32 = 32e3 / Wq_eV - Nph_32;
  if (energy > 9.35 && energy < 9.45) {
    alpha = 0.;
    Nph = Nph_9;
    Ne = Ne_9;
  } else if (energy >= 32.0 && energy < 32.2) {
    Nph = Nph_32;
    Ne = Ne_32;
  } else {  // merged 41.5 keV decay
    Ne = Ne_9 + Ne_32;
    Nph = Nph_9 + Nph_32;
  }

  result.PhotonYield = Nph;
  result.ElectronYield = Ne;
  if (!fdetector->get_OldW13eV()) {
    Ne *= ZurichEXOQ;
    Nph = (result.PhotonYield + result.ElectronYield) - Ne;
    result.PhotonYield = Nph;
    result.ElectronYield = Ne;
  }
  result.ExcitonRatio = NexONi(energy, density);
  result.Lindhard = 1;
  result.ElectricField = dfield;
  result.DeltaT_Scint = deltaT_ns;
  return YieldResultValidity(
      result, energy, Wq_eV);  // everything needed to calculate fluctuations
}

YieldResult NESTcalc::GetYieldsAndQuanta ( double keV, double rho, double def,
INTERACTION_TYPE scatter, const vector<double> &betaMeansPara, const vector<double> &nuclMeansPara ) {//TI
  
  if ( betaMeansPara.size() != default_betaMeansPara.size() ) throw std::runtime_error("ERROR: You need the correct # of NPs.");
  //betaMeansPara are {20.7, -3.2, 0.07, 0.09, -1.10, 0., 35., 1.8, 1., 1.44, 0.5, 0.840, 3.95, 3.13, 0.} (defaults 11/24/2025)
  NESTresult results{};
  YieldResult yields{}; results.yields = yields; QuantaResult quanta{}; results.quanta = quanta;
  
  double Wq = betaMeansPara[0] + betaMeansPara[1] * rho;
  double aX = betaMeansPara[2] + betaMeansPara[3] * rho;
  if ( fdetector->get_OldW13eV() && !fdetector->get_inGas() ) Wq *= ZurichEXOW;
  double Nq = ( 1000. * keV ) / Wq + betaMeansPara[4]; if ( Nq < 0. ) Nq = 0.;
  double keVEff = keV + ( betaMeansPara[5] - keV ) / pow ( ( 1. + pow ( betaMeansPara[6] / keV, betaMeansPara[7] ) ), betaMeansPara[8] );
  
  double xiBase = betaMeansPara[9], xiExpo = betaMeansPara[10], xiOff = betaMeansPara[11];
  double xiTIB = xiBase * pow ( keVEff + xiOff, xiExpo );
  double escape = log ( betaMeansPara[12] + xiTIB ) / xiTIB;
  yields.ExcitonRatio = ( aX - betaMeansPara[14] ) * erf ( keVEff / betaMeansPara[13] ) + betaMeansPara[14];
  if ( escape > 1. ) {
    Nq *= escape; escape = 1.;
  }
  quanta.recombProb = 1. - escape;
  double alpha1 = 1. / ( 1. + yields.ExcitonRatio );
  double Ni = Nq * alpha1;
  yields.ElectronYield = escape * Ni;
  yields.PhotonYield = Nq - yields.ElectronYield;
  
  yields.DeltaT_Scint = -999.;
  yields.Lindhard = 1.;
  yields.ElectricField = def;
  
  Nq = RandomGen::rndm()->binom_draw(int(floor(keV/7e-3+0.5)),Nq/(keV/7e-3));
  double y = escape * alpha1;
  quanta.Variance = ( 1. - y ) * y * Nq;
  quanta.electrons = RandomGen::rndm()->binom_draw(Nq,y);
  quanta.photons = Nq - quanta.electrons;
  quanta.ions = quanta.electrons / escape;
  quanta.excitons = Nq - quanta.ions;
  
  return yields; //in the future, change this to returning the quanta instead, or results
  
}

YieldResult
NESTcalc::GetYieldBetaGR(double energy, double density, double dfield,
                         const std::vector<double> &ERYieldsParam, double multFact) {
  
  if (ERYieldsParam.size() < 10) {
    throw std::runtime_error(
        "ERROR: You need a minimum of 10 nuisance parameters for the mean "
        "yields.");
  }

  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double Wq_eV = wvalue.Wq_eV;
  
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // Liquid Argon
    double p1 = 1;
    double p2 = 10.304;
    double p3 = 9.765245;
    double p4 = 0.10535;
    double p5 = 0.7;
    double alpha = (32.988 - 552.988/(15.08202+pow(dfield/(-4.7+0.025115*exp(1.3954/0.265360653)), 0.1802313)));
    double beta = (1.58904+25.9/(pow(1.105+pow(dfield/0.4, 4.55),7.502)));
    double gamma = 0.645597*(1000/19.5 +6.5*(5-0.5/(pow(dfield/1047.408, 0.01851))));
    double delta = 17.886377;
    double DB = (1052.264+(14159350000 - 1652.264)/(-5+pow(dfield/0.09059867, 1.890901)));
    double LET = -1.578774;
    double Nq = energy * 1e3 / Wq_eV;
    double Qy = alpha * beta +
      (gamma - alpha * beta) / pow(p1 + p2 * pow(energy + 0.5, p3), p4) +
      delta / (p5 + DB * pow(energy, LET));
    double Ly = Nq / energy - Qy;
    double Ne = Qy * energy;
    double Nph = Ly * energy;
    YieldResult result{};
    result.PhotonYield = Nph;
    result.ElectronYield = Ne;
    result.ExcitonRatio = NexONi(energy, density);
    result.Lindhard = 1;
    result.ElectricField = dfield;
    result.DeltaT_Scint = -999;
    return YieldResultValidity(result, energy, Wq_eV);
  }
  
  double alpha = wvalue.alpha;
  double Nq = energy * 1e3 / Wq_eV, m01, m02, m03, m04, m05, m07, m08, m09, m10;
  if (ERYieldsParam[0] < 0.)
    m01 = 30.66 +
          (6.1978 - 30.66) / pow(1. + pow(dfield / 73.855, 2.0318), 0.41883);
  else
    m01 = ERYieldsParam[0];
  if (ERYieldsParam[1] < 0.)
    m02 = 77.2931084;
  else
    m02 = ERYieldsParam[1];
  if (ERYieldsParam[2] < 0.)
    m03 = log10(dfield) * 0.13946236 + 0.52561312;
  else
    m03 = ERYieldsParam[2];
  if (ERYieldsParam[3] < 0.)
    m04 = 1.82217496 + (2.82528809 - 1.82217496) /
                           (1. + pow(dfield / 144.65029656, -2.80532006));
  else
    m04 = ERYieldsParam[3];
  
  if (ERYieldsParam[4] < 0.) {
    m05 = Nq / energy / (1. + alpha * erf(0.05 * energy)) - m01;
    static std::once_flag m5_print_statement;
    std::call_once(m5_print_statement, []() {
            cerr << "Warning: m5 is slightly energy dependent in the beta model" << endl;
        });
  }
  else
    m05 = ERYieldsParam[4];
  if (ERYieldsParam[6] < 0.)
    m07 = 7.02921301 + (98.27936794 - 7.02921301) /
                           (1. + pow(dfield / 256.48156448, 1.29119251));
  else
    m07 = ERYieldsParam[6];
  if (ERYieldsParam[7] < 0.)
    m08 = 4.285781736;
  else
    m08 = ERYieldsParam[7];
  if (ERYieldsParam[8] < 0.)
    m09 = 0.3344049589;
  else
    m09 = ERYieldsParam[8];
  if (ERYieldsParam[9] < 0.)
    m10 = 0.0508273937 + (0.1166087199 - 0.0508273937) /
                             (1. + pow(dfield / 1.39260460e+02, -0.65763592));
  else
    m10 = ERYieldsParam[9];
  double Qy = m01 + (m02 - m01) / pow((1. + pow(energy / m03, m04)), m09) +
              m05 + (0.0 - m05) / pow((1. + pow(energy / m07, m08)), m10);

  if (ERYieldsParam[5] <
      0.) {  // toggle the density and W corrections, which could override you
    double coeff_TI = pow(1. / DENSITY, 0.3);
    double coeff_Ni = pow(1. / DENSITY, 1.4);
    double coeff_OL = pow(1. / DENSITY, -1.7) /
                      log(1. + coeff_TI * coeff_Ni * pow(DENSITY, 1.7));
    Qy *= coeff_OL * log(1. + coeff_TI * coeff_Ni * pow(density, 1.7)) *
          pow(density, -1.7);
    if (!fdetector->get_OldW13eV()) Qy *= ZurichEXOQ;
  }
  Qy *= multFact;
  double Ly = Nq / energy - Qy;
  double Ne = Qy * energy;
  double Nph = Ly * energy;
  double lux_NexONi = alpha * erf(0.05 * energy);

  YieldResult result{};
  result.PhotonYield = Nph;
  result.ElectronYield = Ne;
  result.ExcitonRatio = lux_NexONi;
  result.Lindhard = 1.;
  result.ElectricField = dfield;
  result.DeltaT_Scint = -999;
  return YieldResultValidity(
      result, energy, Wq_eV);  // everything needed to calculate fluctuations;
}

YieldResult NESTcalc::GetYields(INTERACTION_TYPE species, double energy,
                                double density, double dfield, double massNum,
                                double atomNum,
                                const std::vector<double> &NRYieldsParam,
                                const std::vector<double> &ERYieldsParam) {
  switch (species) {
    case NR:
    case WIMP:
    case B8:
    case atmNu:
    case DD:
    case AmBe:
    case Cf:  // this doesn't mean all NR is Cf, this is like a giant if
      // statement. Same intrinsic yields, but different energy spectra
      // (TestSpectra)

      return GetYieldNR(energy, density, dfield, massNum, NRYieldsParam);

      // return GetYieldNROld ( energy, 1 );
      break;
    case ion:
      return GetYieldIon(energy, density, dfield, massNum, atomNum,
                         NRYieldsParam);
      break;
    case gammaRay:
      return GetYieldGamma(energy, density, dfield);
      break;
    case Kr83m:
      return GetYieldKr83m(energy, density, dfield, massNum, atomNum);
      // not actually massNumber, but a place holder for maxTime
      break;
    case fullGamma_PE:
      return GetYieldGamma(energy, density,
                           dfield);  // PE of the full gamma spectrum
      break;
    default:  // beta, CH3T, 14C, the pp solar neutrino background, and
              // Compton/PP spectra of fullGamma
      return GetYieldBetaGR(energy, density, dfield, ERYieldsParam);
      //return GetYieldsAndQuanta ( energy, density, dfield, NEST::beta, ERYieldsParam, NRYieldsParam );
      break;
  }
}

YieldResult NESTcalc::YieldResultValidity(YieldResult &res, const double energy,
                                          const double Wq_eV) {
  assert(res.ElectronYield != -999 && res.PhotonYield != -999 &&
         res.ExcitonRatio != -999);
  if (res.PhotonYield > energy / W_SCINT)
    res.PhotonYield =
        energy / W_SCINT;  // yields can never exceed 1 / [ W ~ few eV ]
  if (res.ElectronYield > energy / W_SCINT)
    res.ElectronYield = energy / W_SCINT;
  if (res.PhotonYield < 0.) res.PhotonYield = 0.;
  if (res.ElectronYield < 0.) res.ElectronYield = 0.;
  res.Lindhard = max(0., min(res.Lindhard, 1.));  // Lindhard Factor
  if (energy < 0.001 * Wq_eV / res.Lindhard) {
    res.PhotonYield = 0.;
    res.ElectronYield = 0.;
  }
  return res;
}

NESTcalc::NESTcalc(VDetector *detector) {
  assert(detector);
  fdetector = detector;

  photon_areas.reserve(2);
  photon_areas.resize(2);
  scintillation.resize(9);
  newSpike.resize(2);
  ionization.resize(9);
}

NESTcalc::~NESTcalc() {
  if (pulseFile) pulseFile.close();
}

const vector<double> &NESTcalc::GetS1(
    const QuantaResult &quanta, double truthPosX, double truthPosY,
    double truthPosZ, double smearPosX, double smearPosY, double smearPosZ,
    double driftVelocity, double dV_mid, INTERACTION_TYPE type_num,
    uint64_t evtNum, double dfield, double energy, S1CalculationMode mode,
    int outputTiming, vector<int64_t> &wf_time, vector<double> &wf_amp) {
  int Nph = quanta.photons;
  double subtract[2] = {0., 0.};

  photon_areas.clear();
  photon_areas.resize(2);

  // This will clear and reset the vector values
  std::fill(scintillation.begin(), scintillation.end(), 0);

  wf_time.clear();
  wf_amp.clear();

  // Add some variability in g1 drawn from a polynomial spline fit
  double posDep =
      fdetector->FitS1(truthPosX, truthPosY, truthPosZ, VDetector::fold);
  double posDepSm;
  if (XYcorr == 1 || XYcorr == 3) {
    posDepSm =
        fdetector->FitS1(smearPosX, smearPosY, smearPosZ, VDetector::unfold);
  } else {
    posDepSm = fdetector->FitS1(0, 0, smearPosZ, VDetector::unfold);
  }

  double dz_center = fdetector->get_TopDrift() -
                     dV_mid * fdetector->get_dtCntr();  // go from t to z
  posDep /= fdetector->FitS1(0., 0., dz_center,
                             VDetector::fold);  // XYZ always in mm now never cm
  posDepSm /= fdetector->FitS1(0., 0., dz_center, VDetector::unfold);
  double g1_XYZ = max(0., min(fdetector->get_g1() * posDep, 1.));
  if (ValidityTests::nearlyEqual(fdetector->get_g1(), 1.)) {
    g1_XYZ = 1.;
    posDep = 1.;
    posDepSm = 1.;
  }
  if (ValidityTests::nearlyEqual(fdetector->get_g1(), 0.)) {
    g1_XYZ = 0.;
    posDep = 0.;
    posDepSm = 0.;
  }

  // generate a number of PMT hits drawn from a binomial distribution.
  // Initialize number of photo-electrons
  int nHits = static_cast<int>(RandomGen::rndm()->binom_draw(Nph, g1_XYZ));
  int Nphe = 0;

  double eff = fdetector->get_sPEeff();
  if (eff < 1.) {
    eff += ((1. - eff) / (2. * static_cast<double>(fdetector->get_numPMTs()))) *
           static_cast<double>(nHits);
  }
  // this functional form is just linear approximation taking us from sPEeff at
  // ~few PMTs firing to 100% when there are enough photons detected for there
  // to be *2* in each PMT
  eff = max(0., min(eff, 1.));

  // Initialize the pulse area and spike count variables
  double pulseArea = 0., spike = 0., prob;

  // If single photo-electron efficiency is under 1 and the threshold is above 0
  // (some phe will be below threshold)

  S1CalculationMode current_mode = mode;
  if (current_mode == S1CalculationMode::Hybrid) {
    // 100 keV_ee at 100 V/cm gives approximately 500 photon hits at g1=10%
    current_mode =
        energy < 100. ? S1CalculationMode::Full : S1CalculationMode::Parametric;
  }

  double NewMean = RandomGen::rndm()->FindNewMean(fdetector->get_sPEres());
  switch (current_mode) {
    case S1CalculationMode::Full:
    case S1CalculationMode::Waveform: {
      // Step through the pmt hits
      for (int i = 0; i < nHits; ++i) {
        // generate photo electron, integer count and area
        // real photo cathodes can't make negative phe
        double TruncGauss = RandomGen::rndm()->rand_zero_trunc_gauss(
            1. / NewMean, fdetector->get_sPEres());

        double phe1 =
            TruncGauss + RandomGen::rndm()->rand_gauss(
                             fdetector->get_noiseBaseline()[0],
                             fdetector->get_noiseBaseline()[1], false);
        ++Nphe;
        if (phe1 > DBL_MAX) {
          phe1 = 1.;  // for Box-Mueller fuck-ups
        }
        prob = RandomGen::rndm()->rand_uniform();
        // zero the area if random draw determines it wouldn't have been
        // observed.
        if (prob > eff) {
          phe1 = 0.;
        }  // add an else with Nphe++ if not doing mc truth
        // Generate a double photo electron if random draw allows it

        double phe2 = 0.;
        if (RandomGen::rndm()->rand_uniform() < fdetector->get_P_dphe()) {
          // generate area and increment the photo-electron counter
          TruncGauss = RandomGen::rndm()->rand_zero_trunc_gauss(
              1. / NewMean, fdetector->get_sPEres());

          phe2 = TruncGauss + RandomGen::rndm()->rand_gauss(
                                  fdetector->get_noiseBaseline()[0],
                                  fdetector->get_noiseBaseline()[1], false);
          ++Nphe;
          if (phe2 > DBL_MAX) {
            phe2 = 1.;
          }
          // zero the area if phe wouldn't have been observed
          if (RandomGen::rndm()->rand_uniform() > eff && prob > eff) {
            phe2 = 0.;
          }  // add an else with Nphe++ if not doing mc truth
             // The dphe occurs simultaneously to the first one from the same
          // source photon. If the first one is seen, so should be the second
          // one
        }
        // Save the phe area and increment the spike count (very perfect spike
        // count) if area is above threshold
        if (current_mode == S1CalculationMode::Waveform) {
          if ((phe1 + phe2) > fdetector->get_sPEthr()) {
            pulseArea += phe1 + phe2;
            ++spike;
            photon_areas[0].emplace_back(phe1);
            photon_areas[1].emplace_back(phe2);
          }
        } else {
          // use approximation to find timing
          if ((phe1 + phe2) > fdetector->get_sPEthr() &&
              (-20. * log(RandomGen::rndm()->rand_uniform()) <
                   fdetector->get_coinWind() ||
               nHits > fdetector->get_coinLevel())) {
            ++spike;
            pulseArea += phe1 + phe2;
          }
        }
      }
      break;
    }
    case S1CalculationMode::Parametric: {
      // Take into account truncated Gaussian shape of SPE and DPE distributions
      // Use the CDFs of the SPE and DPE dists to get the fraction of events
      // below the detectors sPE threshold
      // This will be applied to the digital spike count variable
      double BigPhi_alpha_SPE =
          0.5 * (1. + erf(-1. / fdetector->get_sPEres() / sqrt2));
      double BigPhi_xi_SPE =
          0.5 *
          (1. + erf((fdetector->get_sPEthr() - 1.) / fdetector->get_sPEres() /
                    sqrt2));  // where we'll evaluate the CDF
      double sPE_belowThresh_percentile =
          (BigPhi_xi_SPE - BigPhi_alpha_SPE) / (1. - BigPhi_alpha_SPE);

      // get the same parameters for the DPE distribution
      double BigPhi_alpha_DPE =
          0.5 * (1. + erf(-2. / (sqrt2 * fdetector->get_sPEres()) / sqrt2));
      double BigPhi_xi_DPE =
          0.5 * (1. + erf((fdetector->get_sPEthr() - 2.) /
                          (sqrt2 * fdetector->get_sPEres()) / sqrt2));
      double dPE_belowThresh_percentile =
          (BigPhi_xi_DPE - BigPhi_alpha_DPE) / (1. - BigPhi_alpha_DPE);

      double belowThresh_percentile =
          sPE_belowThresh_percentile * (1. - fdetector->get_P_dphe()) +
          dPE_belowThresh_percentile * fdetector->get_P_dphe();

      Nphe = nHits + static_cast<int>(RandomGen::rndm()->binom_draw(
                         nHits, fdetector->get_P_dphe()));
      eff = fdetector->get_sPEeff();
      if (eff < 1.) {
        eff +=
            ((1. - eff) /
             (2. * static_cast<double>(fdetector->get_numPMTs()))) *
            static_cast<double>(nHits);  // same as Full S1CalculationMode case
      }
      // Above efficiency adjustment needs to be 'NPhe' instead of 'nHits' for
      // Flamedisx implementation
      eff = max(0., min(eff, 1.));
      auto Nphe_det = static_cast<double>(RandomGen::rndm()->binom_draw(
          Nphe, 1. - (1. - eff) / (1. + fdetector->get_P_dphe())));
      // take into account the truncation of the PE distributions
      pulseArea = RandomGen::rndm()->rand_gauss(
          Nphe_det * (1. / NewMean),
          fdetector->get_sPEres() * sqrt(Nphe_det / NewMean), true);
      spike = static_cast<double>(RandomGen::rndm()->binom_draw(
          nHits, eff * (1. - belowThresh_percentile)));

      break;
    }

    case S1CalculationMode::Hybrid: {
      default:

        break;
    }
  }

  if (current_mode == S1CalculationMode::Waveform) {
    vector<double> PEperBin, AreaTable[2], TimeTable[2];
    int numPts = podLength - 100 * SAMPLE_SIZE;
    AreaTable[0].resize(numPts, 0.);
    AreaTable[1].resize(numPts, 0.);

    int total_photons = (int)std::abs(spike);
    int excitons = int(double(total_photons) * double(quanta.excitons) /
                       double(quanta.photons));
    photonstream photon_emission_times =
        GetPhotonTimes(type_num, total_photons, excitons, dfield, energy);
    photonstream photon_times = AddPhotonTransportTime(
        photon_emission_times, truthPosX, truthPosY, truthPosZ);

    if (outputTiming >= 0 && !pulseFile.is_open()) {
      pulseFile.open("photon_times.txt");
      if ( outputTiming == 1 )
	pulseFile << "Event#\tt [ns]\tPEb/bin\tPEt/bin\tin win" << endl;
      else
	pulseFile << "Event#\tt [ns]" << endl;
    }
    
    if ( outputTiming == 2 ) {
      for ( int ii = 0; ii < (int)std::abs(spike); ++ii ) {
	char line[80];
	snprintf(
		 line, 80, "%llu\t%.3f", (long long unsigned int)evtNum,
		photon_times[ii]);
	pulseFile << line << endl;
      }
    } else {

    int ii, index;
    double min = 1e100, pTime;
    for (ii = 0; ii < (int)std::abs(spike); ++ii) {
      PEperBin.clear();
      PEperBin = fdetector->SinglePEWaveForm(
          photon_areas[0][ii] + photon_areas[1][ii], photon_times[ii]);
      int total = static_cast<int>(PEperBin.size()) - 1;
      int whichArray;
      if (RandomGen::rndm()->rand_uniform() <
          fdetector->FitTBA(truthPosX, truthPosY, truthPosZ)[0]) {
        whichArray = 0;
      } else {
        whichArray = 1;
      }
      for (int kk = 0; kk < total; ++kk) {
        pTime = PEperBin[0] + kk * SAMPLE_SIZE;
        index = int(floor(pTime / SAMPLE_SIZE + 0.5)) + numPts / 2;
        if (index < 0) {
          index = 0;
        }
        if (index >= numPts) {
          index = numPts - 1;
        }
        AreaTable[whichArray][index] +=
            10. * (1. + PULSEHEIGHT) *
            (photon_areas[0][ii] + photon_areas[1][ii]) /
            (PULSE_WIDTH * sqrt2_PI) *
            exp(-pow(pTime - photon_times[ii], 2.) /
                (2. * PULSE_WIDTH * PULSE_WIDTH));
      }
      if (total >= 0) {
        if (PEperBin[0] < min) {
          min = PEperBin[0];
        }
        TimeTable[0].emplace_back(PEperBin[0]);
      }
    }
    double tRandOffset =
        (SAMPLE_SIZE / 2.) *
        (2. * RandomGen::rndm()->rand_uniform() -
         1.);  //-16,20 was good for LUX, but made weird skew in fP
    for (ii = 0; ii < numPts; ++ii) {
      if ((AreaTable[0][ii] + AreaTable[1][ii]) <= PULSEHEIGHT) {
        continue;
      }

      wf_time.emplace_back((ii - numPts / 2) * SAMPLE_SIZE);
      wf_amp.emplace_back(AreaTable[0][ii] + AreaTable[1][ii]);

      if (outputTiming >= 0) {
        char line[80];
        if (AreaTable[0][ii] > PHE_MAX) {
          subtract[0] = AreaTable[0][ii] - PHE_MAX;
        } else {
          subtract[0] = 0.0;
        }
        if (AreaTable[1][ii] > PHE_MAX) {
          subtract[1] = AreaTable[1][ii] - PHE_MAX;
        } else {
          subtract[1] = 0.0;
        }
        snprintf(
            line, 80, "%llu\t%lld\t%.3f\t%.3f", (long long unsigned int)evtNum,
            (long long int)wf_time.back() + (long long int)tRandOffset,
            AreaTable[0][ii] - subtract[0], AreaTable[1][ii] - subtract[1]);
        pulseFile << line << flush;
      }

      if (((ii - numPts / 2) * SAMPLE_SIZE - (int)min) >
              fdetector->get_coinWind() &&
          nHits <= fdetector->get_coinLevel()) {
        pulseArea -= (AreaTable[0][ii] + AreaTable[1][ii]);
        pulseFile << "\t0" << endl;
      } else {
        pulseFile << "\t1" << endl;
      }
    }
    for (ii = 0; ii < TimeTable[0].size(); ++ii) {
      if ((TimeTable[0][ii] - min) > fdetector->get_coinWind() &&
          nHits <= fdetector->get_coinLevel()) {
        --spike;
      }
    }
    }
  }
  
  if (fdetector->get_noiseLinear()[0] >= 1.0)
    cerr << " !!WARNING!! S1 linear noise term is greater than or equal to 100% "
            "(i.e. 1.0) Did you mistake fraction for percent??"
         << endl;

  if (fdetector->get_noiseQuadratic()[0] != 0) {
    pulseArea = RandomGen::rndm()->rand_gauss(
        pulseArea,
        sqrt(
            pow(fdetector->get_noiseQuadratic()[0] * pulseArea * pulseArea, 2) +
            pow(fdetector->get_noiseLinear()[0] * pulseArea, 2)),
        true);
  } else {
    pulseArea = RandomGen::rndm()->rand_gauss(
        pulseArea, fdetector->get_noiseLinear()[0] * pulseArea, true);
  }
  pulseArea -= (subtract[0] + subtract[1]);
  if (pulseArea < fdetector->get_sPEthr()) pulseArea = 0.;
  if (spike < 0) spike = 0;
  double pulseAreaC = pulseArea / posDepSm;
  double Nphd = pulseArea / (1. + fdetector->get_P_dphe());
  double NphdC = pulseAreaC / (1. + fdetector->get_P_dphe());
  double spikeC = spike / posDepSm;

  scintillation[0] = nHits;  // MC-true integer hits in same OR different PMTs,
  // NO double phe effect
  scintillation[1] =
      Nphe;  // MC-true integer hits WITH double phe effect (Nphe > nHits)
  scintillation[2] = pulseArea;  // floating real# smeared DAQ pulse areas in
  // phe, NO XYZ correction
  scintillation[3] =
      pulseAreaC;  // smeared DAQ pulse areas in phe, WITH XYZ correction
  scintillation[4] = Nphd;  // same as pulse area, adjusted/corrected *downward*
  // for 2-PE effect (LUX phd units)
  scintillation[5] = NphdC;   // same as Nphd, but XYZ-corrected
  scintillation[6] = spike;   // floating real# spike count, NO XYZ correction
  scintillation[7] = spikeC;  // floating real# spike count, WITH XYZ correction
  scintillation[8] = spike;   // USE FOR EXTERNAL LZLAMA COINCIDENCE CALCULATION

  if (spike < fdetector->get_coinLevel())  // no chance of meeting coincidence
    // requirement. Here, spike is still
    // "perfect" (integer)
    prob = 0.;
  else {
    if (spike > 10.)
      prob = 1.;
    else {
      if (fdetector->get_coinLevel() == 0)
        prob = 1.;
      else if (fdetector->get_coinLevel() == 1) {
        if (spike >= 1.)
          prob = 1.;
        else {
          prob = 0.;
        }
      } else if (fdetector->get_coinLevel() == 2) {
        prob = 1. - pow((double)fdetector->get_numPMTs(), 1. - spike);
      } else {
        double numer = 0., denom = 0.;
        for (int i = spike; i > 0; --i) {
          denom += nCr(fdetector->get_numPMTs(), i);
          if (i >= fdetector->get_coinLevel())
            numer += nCr(fdetector->get_numPMTs(), i);
        }
        prob = numer / denom;
      }  // end of case of coinLevel of 3 or higher
    }    // end of case of spike is equal to 9 or lower
  }      // the end of case of spike >= coinLevel

  if (spike >= 1. && spikeC > 0.) {
    // over-write spike with smeared version, ~real data. Last chance to read
    // out digital spike and spikeC in scintillation[6] and [7]
    GetSpike(Nph, smearPosX, smearPosY, smearPosZ, driftVelocity, dV_mid,
             scintillation);
    scintillation[6] = newSpike[0];  // S1 spike count (NOT adjusted for double
    // phe effect), IF sufficiently small nHits
    // (otherwise = Nphd)
    scintillation[7] =
        newSpike[1];  // same as newSpike[0], but WITH XYZ correction
  }

  if (RandomGen::rndm()->rand_uniform() > prob &&
      prob < 1.) {  // coincidence has to happen in different PMTs
    // some of these are set to -1 to flag them as having been below threshold
    if (ValidityTests::nearlyEqual(scintillation[0], 0.))
      scintillation[0] = PHE_MIN;
    scintillation[0] = -1. * std::abs(scintillation[0]);
    if (ValidityTests::nearlyEqual(scintillation[1], 0.))
      scintillation[1] = PHE_MIN;
    scintillation[1] = -1. * std::abs(scintillation[1]);
    if (ValidityTests::nearlyEqual(scintillation[2], 0.))
      scintillation[2] = PHE_MIN;
    scintillation[2] = -1. * std::abs(scintillation[2]);
    if (ValidityTests::nearlyEqual(scintillation[3], 0.))
      scintillation[3] = PHE_MIN;
    scintillation[3] = -1. * std::abs(scintillation[3]);
    if (ValidityTests::nearlyEqual(scintillation[4], 0.))
      scintillation[4] = PHE_MIN;
    scintillation[4] = -1. * std::abs(scintillation[4]);
    if (ValidityTests::nearlyEqual(scintillation[5], 0.))
      scintillation[5] = PHE_MIN;
    scintillation[5] = -1. * std::abs(scintillation[5]);
    if (ValidityTests::nearlyEqual(scintillation[6], 0.))
      scintillation[6] = PHE_MIN;
    scintillation[6] = -1. * std::abs(scintillation[6]);
    if (ValidityTests::nearlyEqual(scintillation[7], 0.))
      scintillation[7] = PHE_MIN;
    scintillation[7] = -1. * std::abs(scintillation[7]);
  }

  // scintillation[8] =
  // fdetector->get_g1();  // g1 (light collection efficiency in liquid)

  return scintillation;
}

const vector<double> &NESTcalc::GetS2(
    int Ne, double truthPosX, double truthPosY, double truthPosZ,
    double smearPosX, double smearPosY, double smearPosZ, double dt,
    double driftVelocity, uint64_t evtNum, double dfield,
    S2CalculationMode mode, int outputTiming, vector<int64_t> &wf_time,
    vector<double> &wf_amp, const vector<double> &g2_params) {
  double elYield = g2_params[0];
  double ExtEff = g2_params[1];
  double SE = g2_params[2];
  double g2 = g2_params[3];
  double gasGap = g2_params[4];

  std::fill(ionization.begin(), ionization.end(), 0);

  double subtract[2] = {0., 0.};
  int i;
  bool eTrain = false;
  if (mode == S2CalculationMode::WaveformWithEtrain &&
      !fdetector->get_inGas()) {
    eTrain = true;
  }

  if (dfield < FIELD_MIN  //"zero"-drift-field detector has no S2
      || elYield <= 0. || ExtEff <= 0. || SE <= 0. || g2 <= 0. ||
      gasGap <= 0.) {
    return ionization;
  }

  // Add some variability in g1_gas drawn from a polynomial spline fit
  double posDep =
      fdetector->FitS2(truthPosX, truthPosY,
                       VDetector::fold);  // XY is always in mm now, never cm
  double posDepSm;
  if (XYcorr == 2 || XYcorr == 3) {
    posDepSm = fdetector->FitS2(smearPosX, smearPosY, VDetector::unfold);
  } else {
    posDepSm = fdetector->FitS2(0, 0, VDetector::unfold);
  }
  posDep /= fdetector->FitS2(0., 0., VDetector::fold);
  posDepSm /= fdetector->FitS2(0., 0., VDetector::unfold);
  double dz = fdetector->get_TopDrift() - dt * driftVelocity;

  if (ValidityTests::nearlyEqual(fdetector->get_g1_gas(), 1.)) {
    posDep = 1.;
    posDepSm = 1.;
  }
  if (ValidityTests::nearlyEqual(fdetector->get_g1_gas(), 0.)) {
    posDep = 0.;
    posDepSm = 0.;
  }

  int Nee = RandomGen::rndm()->binom_draw(
      Ne, ExtEff * exp(-dt / fdetector->get_eLife_us()));
  // MAKE this 1 for SINGLE e- DEBUG

  uint64_t Nph = 0, nHits = 0, Nphe = 0;
  double pulseArea = 0.;

  if (mode == S2CalculationMode::Waveform ||
      mode == S2CalculationMode::WaveformWithEtrain) {
    uint64_t k;
    int stopPoint;
    double tau1, tau2, E_liq, amp2;
    vector<double> electronstream, AreaTableBot[2], AreaTableTop[2], TimeTable;
    if (eTrain) {
      stopPoint = RandomGen::rndm()->binom_draw(
          Ne, exp(-dt / fdetector->get_eLife_us()));
    } else {
      stopPoint = Nee;
    }
    electronstream.resize(stopPoint, dt);
    double elecTravT = 0., DL, DL_time, DT, phi, sigX, sigY, newX, newY;
    double Diff_Tran =
      GetDiffTran_Liquid(dfield, false, fdetector->get_T_Kelvin(), fdetector->get_p_bar(), DENSITY, ATOM_NUM);
    double Diff_Long =
      GetDiffLong_Liquid(dfield, false, fdetector->get_T_Kelvin(), fdetector->get_p_bar(), DENSITY, ATOM_NUM);

    // a good rule of thumb but only for liquids, as gas kind of opposite:
    // Diff_Long ~ 0.15 * Diff_Tran, as it is in LAr, at least as field goes to
    // infinity
    double Diff_Long_Gas =
        4.265 + 19097. / (1e3 * fdetector->get_E_gas()) -
        1.7397e6 / pow(1e3 * fdetector->get_E_gas(), 2.) +
        1.2477e8 / pow(1e3 * fdetector->get_E_gas(), 3.);  // Nygren, NEXT
    double Diff_Tran_Gas = Diff_Tran * 0.01;
    if (fdetector->get_inGas()) {
      Diff_Tran *= 0.01;
      Diff_Long = 4.265 + 19097. / dfield - 1.7397e6 / pow(dfield, 2.) +
                  1.2477e8 / pow(dfield, 3.);
    }
    double sigmaDL =
        10. * sqrt(2. * Diff_Long * dt *
                   1e-6);  // sqrt of cm^2/s * s = cm; times 10 for mm.
    double sigmaDT = 10. * sqrt(2. * Diff_Tran * dt * 1e-6);
    bool YesGas = true;
    double rho = GetDensity(fdetector->get_T_Kelvin(), fdetector->get_p_bar(),
                            YesGas, 1, fdetector->get_molarMass());
    double driftVelocity_gas =
      GetDriftVelocity_MagBoltz(fdetector->get_T_Kelvin(), rho, fdetector->get_E_gas() * 1000., fdetector->get_p_bar(), fdetector->get_molarMass());
    double dt_gas = gasGap / driftVelocity_gas;
    double sigmaDLg = 10. * sqrt(2. * Diff_Long_Gas * dt_gas * 1e-6);
    double sigmaDTg = 10. * sqrt(2. * Diff_Tran_Gas * dt_gas * 1e-6);
    double tauTrap = 0.28326 + 5303/(dfield*dfield);  // microseconds, to match
    // LZ SR3, LUX Run03, Xe100/10. 0.185 (fixed) based on 1310.1117 (Gaussian)
    double min = 1e100;
    for (i = 0; i < stopPoint; ++i) {
      elecTravT = 0.;  // resetting for the current electron
      DL = RandomGen::rndm()->rand_gauss(0., sigmaDL, false);
      DT = std::abs(RandomGen::rndm()->rand_gauss(0., sigmaDT, false));
      phi = two_PI * RandomGen::rndm()->rand_uniform();
      sigX = DT * cos(phi);
      sigY = DT * sin(phi);
      newX = truthPosX + sigX;
      newY = truthPosY + sigY;
      if (newX * newX + newY * newY >
          fdetector->get_radmax() * fdetector->get_radmax()) {
        continue;  // remove electrons from outside the maximum possible radius
                   // (alternative is squeeze them, depending on your E-fields)
      }
      DL_time = DL / driftVelocity;
      elecTravT += DL_time;
      if (!fdetector->get_inGas() && fdetector->get_E_gas() != 0.) {
        elecTravT -= tauTrap * log(RandomGen::rndm()->rand_uniform());
      }
      electronstream[i] += elecTravT;
      SE = floor(RandomGen::rndm()->rand_gauss(
                     elYield, sqrt(fdetector->get_s2Fano() * elYield), true) +
                 0.5);
      Nph += uint64_t(SE);
      SE = (double)RandomGen::rndm()->binom_draw(
          uint64_t(SE), fdetector->get_g1_gas() * posDep);
      nHits += uint64_t(SE);
      double KE = 0.5 * 9.109e-31 * driftVelocity_gas * driftVelocity_gas *
                  1e6 / 1.602e-16;
      double origin = fdetector->get_TopDrift() + gasGap / 2.;
      QuantaResult quanta{};
      quanta.photons = int(SE);
      quanta.electrons = 0;
      quanta.ions = 0;
      quanta.excitons = int(floor(0.0566 * SE + 0.5));
      photonstream photon_emission_times = GetPhotonTimes(
          NEST::beta, quanta.photons, quanta.excitons, dfield, KE);
      photonstream photon_times =
          AddPhotonTransportTime(photon_emission_times, newX, newY, origin);
      SE += (double)RandomGen::rndm()->binom_draw(uint64_t(SE),
                                                  fdetector->get_P_dphe());
      Nphe += uint64_t(SE);
      DL = RandomGen::rndm()->rand_gauss(0., sigmaDLg, false);
      DT = std::abs(RandomGen::rndm()->rand_gauss(0., sigmaDTg, false));
      phi = two_PI * RandomGen::rndm()->rand_uniform();
      sigX = DT * cos(phi);
      sigY = DT * sin(phi);
      newX += sigX;
      newY += sigY;
      DL_time = DL / driftVelocity_gas;
      electronstream[i] += DL_time;
      if (i >= Nee && eTrain) {  // exponential based on arXiv:1711.07025, power
                                 // on 2004.07791
        E_liq = fdetector->get_E_gas() / (EPS_LIQ / std::abs(EPS_GAS));
        tau2 = (fdetector->get_TopDrift() /
                driftVelocity);  // 0.58313 * exp(0.20929 * E_liq) * 1e3;
        tau1 = 1.40540 * exp(0.15578 * E_liq) * 1e3 * 1e-2;
        amp2 = 0.38157 * exp(0.21177 * E_liq) * 1e-2;
        if (RandomGen::rndm()->rand_uniform() < (amp2 / 0.035) * ExtEff) {
          tau2 /= RandomGen::rndm()->rand_uniform();
          if (tau2 > 1e6) tau2 = 1e6;  // 1 sec. cap
          electronstream[i] += tau2;
        } else {
          electronstream[i] -= tau1 * log(RandomGen::rndm()->rand_uniform());
        }
      }
      for (double j = 0.; j < SE; j += 1.) {
        double phe = RandomGen::rndm()->rand_zero_trunc_gauss(
            1. / RandomGen::rndm()->FindNewMean(fdetector->get_sPEres()),
            fdetector->get_sPEres());
        if (i < Nee || !eTrain) pulseArea += phe;
        origin = fdetector->get_TopDrift() +
                 gasGap * RandomGen::rndm()->rand_uniform();
        k = uint64_t(j);
        if (k >= photon_times.size()) k -= photon_times.size();
        double offset = ((fdetector->get_anode() - origin) / driftVelocity_gas +
                         electronstream[i]) *
                            1e3 +
                        photon_times[k];
        if (offset < min) min = offset;
        if (RandomGen::rndm()->rand_uniform() <
            fdetector->FitTBA(truthPosX, truthPosY, truthPosZ)[1]) {
          AreaTableBot[0].emplace_back(phe);
          AreaTableTop[0].emplace_back(0.0);
        } else {
          AreaTableBot[0].emplace_back(0.0);
          AreaTableTop[0].emplace_back(phe);
        }
        TimeTable.emplace_back(offset);
      }
    }
    int numPts = Nphe * 1000;
    if (numPts < 1000 / SAMPLE_SIZE) numPts = 1000 / SAMPLE_SIZE;
    AreaTableBot[1].resize(numPts, 0.);
    AreaTableTop[1].resize(numPts, 0.);
    min -= 5. * SAMPLE_SIZE;
    for (k = 0; k < Nphe; ++k) {
      vector<double> PEperBin;
      if (ValidityTests::nearlyEqual(AreaTableBot[0][k], 0.0))
        PEperBin =
            fdetector->SinglePEWaveForm(AreaTableTop[0][k], TimeTable[k] - min);
      else {
        PEperBin =
            fdetector->SinglePEWaveForm(AreaTableBot[0][k], TimeTable[k] - min);
      }
      for (i = 0; i < int(PEperBin.size()) - 1; ++i) {
        double eTime = PEperBin[0] + i * SAMPLE_SIZE;
        int index = int(floor(eTime / SAMPLE_SIZE + 0.5));
        index = NESTcalc::clamp(index, 0, numPts - 1);
        if (ValidityTests::nearlyEqual(AreaTableBot[0][k], 0.0))
          AreaTableTop[1][index] += 10. * AreaTableTop[0][k] /
                                    (PULSE_WIDTH * sqrt2_PI) *
                                    exp(-pow(eTime - TimeTable[k] + min, 2.) /
                                        (2. * PULSE_WIDTH * PULSE_WIDTH));
        else {
          AreaTableBot[1][index] += 10. * AreaTableBot[0][k] /
                                    (PULSE_WIDTH * sqrt2_PI) *
                                    exp(-pow(eTime - TimeTable[k] + min, 2.) /
                                        (2. * PULSE_WIDTH * PULSE_WIDTH));
        }
      }
    }
    for (k = 0; k < numPts; ++k) {
      if ((AreaTableBot[1][k] + AreaTableTop[1][k]) <= PULSEHEIGHT) continue;
      wf_time.emplace_back(k * SAMPLE_SIZE + int64_t(min + SAMPLE_SIZE / 2.));
      wf_amp.emplace_back(AreaTableBot[1][k] + AreaTableTop[1][k]);

      if (outputTiming >= 0) {
        char line[80];
        if (AreaTableBot[1][k] > PHE_MAX)
          subtract[0] = AreaTableBot[1][k] - PHE_MAX;
        else {
          subtract[0] = 0.0;
        }
        if (AreaTableTop[1][k] > PHE_MAX)
          subtract[1] = AreaTableTop[1][k] - PHE_MAX;
        else {
          subtract[1] = 0.0;
        }
        snprintf(line, 80, "%llu\t%lld\t%.3f\t%.3f",
                 (long long unsigned int)evtNum, (long long int)wf_time.back(),
                 AreaTableBot[1][k] - subtract[0],
                 AreaTableTop[1][k] - subtract[1]);
        pulseFile << line << endl;
      }
    }
  } else {
    Nph = uint64_t(
        floor(RandomGen::rndm()->rand_gauss(
                  elYield * double(Nee),
                  sqrt(fdetector->get_s2Fano() * elYield * double(Nee)), true) +
              0.5));
    nHits =
        RandomGen::rndm()->binom_draw(Nph, fdetector->get_g1_gas() * posDep);
    Nphe =
        nHits + RandomGen::rndm()->binom_draw(nHits, fdetector->get_P_dphe());
    double NewMean = RandomGen::rndm()->FindNewMean(fdetector->get_sPEres());
    pulseArea = RandomGen::rndm()->rand_gauss(
        Nphe / NewMean, fdetector->get_sPEres() * sqrt(Nphe / NewMean), true);
  }

  if (fdetector->get_noiseLinear()[1] >= 1.0)
    cerr << " !!WARNING!! S2 linear noise term is greater than or equal to 100% "
            "(i.e. 1.0) Did you mistake fraction for percent??"
         << endl;
  if (fdetector->get_noiseQuadratic()[1] != 0) {
    pulseArea = RandomGen::rndm()->rand_gauss(
        pulseArea,
        sqrt(pow(fdetector->get_noiseQuadratic()[1] * pow(pulseArea, 2), 2) +
             pow(fdetector->get_noiseLinear()[1] * pulseArea, 2)),
        true);
  } else {
    pulseArea = RandomGen::rndm()->rand_gauss(
        pulseArea, fdetector->get_noiseLinear()[1] * pulseArea, true);
  }
  pulseArea -= (subtract[0] + subtract[1]);
  double pulseAreaC =
      pulseArea / exp(-dt / fdetector->get_eLife_us()) / posDepSm;
  double Nphd = pulseArea / (1. + fdetector->get_P_dphe());
  double NphdC = pulseAreaC / (1. + fdetector->get_P_dphe());

  double S2b = RandomGen::rndm()->rand_gauss(
      fdetector->FitTBA(truthPosX, truthPosY, truthPosZ)[1] * pulseArea,
      sqrt(fdetector->FitTBA(truthPosX, truthPosY, truthPosZ)[1] * pulseArea *
           (1. - fdetector->FitTBA(truthPosX, truthPosY, truthPosZ)[1])),
      true);
  double S2bc =
      S2b / exp(-dt / fdetector->get_eLife_us()) /
      posDepSm;  // for detectors using S2 bottom-only in their analyses

  ionization[0] = Nee;  // integer number of electrons unabsorbed in liquid then
  // getting extracted
  ionization[1] = Nph;    // raw number of photons produced in the gas gap
  ionization[2] = nHits;  // MC-true integer hits in same OR different PMTs, NO
  // double phe effect
  ionization[3] = Nphe;  // MC-true integer hits WITH double phe effect (Nphe >
  // nHits). S2 has more steps than S1 (e's 1st)
  if (fdetector->get_s2_thr() >= 0) {
    ionization[4] = pulseArea;  // floating real# smeared DAQ pulse areas in
    // phe, NO XYZ correction
    ionization[5] =
        pulseAreaC;  // smeared DAQ pulse areas in phe, WITH XYZ correction
    ionization[6] = Nphd;  // same as pulse area, adjusted/corrected *downward*
    // for 2-PE effect (LUX phd units)
    ionization[7] = NphdC;  // same as Nphd, but XYZ-corrected
  }
  // Negative S2 threshold is a hidden feature, which switches from S2 -> S2
  // bottom (NOT literally negative)
  else {
    ionization[4] = S2b;  // floating real# smeared pulse areas in phe ONLY
    // including bottom PMTs, NO XYZ correction
    ionization[5] = S2bc;  // floating real# smeared pulse areas in phe ONLY
    // including bottom PMTs, WITH XYZ correction
    ionization[6] =
        S2b / (1. + fdetector->get_P_dphe());  // same as S2b, but adjusted for
    // 2-PE effect (LUX phd units)
    ionization[7] = S2bc / (1. + fdetector->get_P_dphe());  // same as S2bc, but
                                                            // adjusted for 2-PE
                                                            // effect (LUX phd
                                                            // units)
  }

  if (pulseArea < std::abs(fdetector->get_s2_thr())) {
    for (i = 0; i < 8; ++i) {
      if (ValidityTests::nearlyEqual(ionization[i], 0.))
        ionization[i] = PHE_MIN;
      ionization[i] = -1. * std::abs(ionization[i]);
    }
  }

  ionization[8] =
      g2;  // g2 = ExtEff * SE, gain of EL in gas gap (from CalculateG2)

  return ionization;
}

vector<double> NESTcalc::CalculateG2(int verbosity) {
  vector<double> g2_params(5);

  // Set parameters for calculating EL yield and extraction
  double alpha = 0.137, beta = 4.70e-18,
         gamma = 0;  // note the value of alpha is similar to ~1/7eV. Not
                     // coincidence. Noted in Mock et al.
  // actually listed as 'a' and 'b' in ref (below). Units 1/V, cm^2
  double epsilonRatio = EPS_LIQ / std::abs(EPS_GAS);
  if (fdetector->get_inGas())
    epsilonRatio = 1.;  // in an all-gas detector, E_liq variable below simply
  // becomes the field value between anode and gate

  // Convert gas extraction field to liquid field
  double E_liq = fdetector->get_E_gas() / epsilonRatio;  // kV per cm
  double ExtEff;
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.))  // Argon
    ExtEff =
        1. - 1.1974 * exp(-1.003 *
                          pow(E_liq, 1.3849));  // Guschin 1978-79 and 1981-82
  else {
    if (EPS_GAS < 0.) {
      ExtEff =
          1. -
          exp(-0.12172 *
              pow(E_liq, 2.0691));  // Columbia and PandaX: much higher than
                                    // everyone else, so tucked away as optional
    } else {
      double T_Kelvin =
          fdetector->get_T_Kelvin();  // data was available at 160(solid), 165,
                                      // 170, 173, 175, 177, 179, 181 K (can't
                                      // find PandaX)
      double em1 = 8.807528626640e4 - 2.026247730928e3 * T_Kelvin +
                   1.747197309338e1 * pow(T_Kelvin, 2.) -
                   6.692362929271e-2 * pow(T_Kelvin, 3.) +
                   9.607626262594e-5 * pow(T_Kelvin, 4.);  // ~1
      double em2 = 5.074800229635e5 -                      // ~0.05
                   1.460168019275e4 * T_Kelvin +
                   1.680089978382e2 * pow(T_Kelvin, 2.) -
                   9.663183204468e-1 * pow(T_Kelvin, 3.) +
                   2.778229721617e-3 * pow(T_Kelvin, 4.) -
                   3.194249083426e-6 * pow(T_Kelvin, 5.);
      double em3 = -4.659269964120e6 +  // ~1-5
                   1.366555237249e5 * T_Kelvin -
                   1.602830617076e3 * pow(T_Kelvin, 2.) +
                   9.397480411915e-0 * pow(T_Kelvin, 3.) -
                   2.754232523872e-2 * pow(T_Kelvin, 4.) +
                   3.228101180588e-5 * pow(T_Kelvin, 5.);
      ExtEff =
          1. -
          em1 * exp(-em2 *
                    pow(E_liq,
                        em3));  // combination of GusX4 (RED fav), PIXeY,
                                // LUX Run03, LLNLx2, LUX Run04, XENON10,100
    }
  }
  if (ExtEff > 1. || fdetector->get_inGas()) ExtEff = 1.;
  if (ExtEff < 0. || E_liq <= 0.) ExtEff = 0.;

  double gasGap =
      fdetector->get_anode() -
      fdetector
          ->get_TopDrift();  // EL gap in mm -> cm, affecting S2 size linearly
  if (gasGap <= 0. && E_liq > 0.) {
    throw std::runtime_error(
        "\tERR: The gas gap in the S2 calculation broke!!!!");
  }

  // Calculate EL yield based on gas gap, extraction field, and pressure
  // double elYield = (alpha * fdetector->get_E_gas() * 1e3 -
  //                beta * fdetector->get_p_bar() - gamma) *
  //               gasGap * 0.1;  // arXiv:1207.2292 (HA, Vitaly C.)
  bool YesGas = true;
  double rho = GetDensity(fdetector->get_T_Kelvin(), fdetector->get_p_bar(),
                          YesGas, 1, fdetector->get_molarMass());
  double elYield;
  if (ValidityTests::nearlyEqual(
          ATOM_NUM, 18.)) {  // Henrique Araujo and Vitaly Chepel again
    alpha = 0.0813;
    beta = 1.90e-18;
  }
  elYield = (alpha * fdetector->get_E_gas() * 1e3 -
             beta * (NEST_AVO * rho / fdetector->get_molarMass())) *
            gasGap * 0.1;
  // replaced with more accurate version also from 1207.2292, but works for room
  // temperature gas
  if (elYield <= 0.0 && E_liq != 0.) {
    cerr << "\tWARNING, the field in gas must be at least "
         << 1e-3 * beta * NEST_AVO * rho / (alpha * fdetector->get_molarMass())
         << " kV/cm, for S2 to work," << endl;
    cerr << "\tOR: your density for gas must be less than "
         << fdetector->get_molarMass() * alpha * fdetector->get_E_gas() * 1e3 /
                (beta * NEST_AVO)
         << " g/cm^3." << endl;
  }
  // Calculate single electron size and then g2
  double SE = elYield * fdetector->get_g1_gas();  // multiplying by light
  // collection efficiency in
  // the gas gap
  if (fdetector->get_s2_thr() < 0)
    SE *= fdetector->FitTBA(0., 0., fdetector->get_TopDrift() / 2.)[1];
  double g2 = ExtEff * SE;
  double StdDev = 0., Nphe, pulseArea, pulseAreaC, NphdC, phi, posDep, r, x, y;
  int Nph, nHits, numSE = 10000;
  if (verbosity > 0) {
    double muSE = 0.;
    for (int i = 0; i < numSE; ++i) {
      // calculate properly the width (1-sigma std dev) in the SE size
      Nph = int(
          floor(RandomGen::rndm()->rand_gauss(
                    elYield, sqrt(fdetector->get_s2Fano() * elYield), true) +
                0.5));
      phi = two_PI * RandomGen::rndm()->rand_uniform();
      r = fdetector->get_radius() * sqrt(RandomGen::rndm()->rand_uniform());
      x = r * cos(phi);
      y = r * sin(phi);
      posDep = fdetector->FitS2(x, y, VDetector::fold) /
               fdetector->FitS2(
                   0., 0., VDetector::fold);  // future upgrade: smeared pos
      nHits =
          RandomGen::rndm()->binom_draw(Nph, fdetector->get_g1_gas() * posDep);
      Nphe =
          nHits + RandomGen::rndm()->binom_draw(nHits, fdetector->get_P_dphe());
      pulseArea = RandomGen::rndm()->rand_gauss(
          Nphe, fdetector->get_sPEres() * sqrt(Nphe), true);
      if (fdetector->get_noiseQuadratic()[1] != 0) {
        pulseArea = RandomGen::rndm()->rand_gauss(
            pulseArea,
            sqrt(
                pow(fdetector->get_noiseQuadratic()[1] * pow(pulseArea, 2), 2) +
                pow(fdetector->get_noiseLinear()[1] * pulseArea, 2)),
            true);
      } else {
        pulseArea = RandomGen::rndm()->rand_gauss(
            pulseArea, fdetector->get_noiseLinear()[1] * pulseArea, true);
      }
      if (fdetector->get_s2_thr() < 0.)
        pulseArea = RandomGen::rndm()->rand_gauss(
            fdetector->FitTBA(0.0, 0.0, fdetector->get_TopDrift() / 2.)[1] *
                pulseArea,
            sqrt(
                fdetector->FitTBA(0.0, 0.0, fdetector->get_TopDrift() / 2.)[1] *
                pulseArea *
                (1. - fdetector->FitTBA(0.0, 0.0,
                                        fdetector->get_TopDrift() / 2.)[1])),
            true);
      pulseAreaC = pulseArea / posDep;
      NphdC = pulseAreaC / (1. + fdetector->get_P_dphe());
      StdDev += (SE - NphdC) * (SE - NphdC);
      muSE += NphdC;
    }
    SE = muSE / double(numSE);
    StdDev =
        sqrt(StdDev) / sqrt(double(numSE) - 1.);  // N-1 from above (10,000)

    cout << endl
         << "g1 = " << fdetector->get_g1() << " phd per photon\tg2 = " << g2
         << " phd per electron (e-EE = ";
    cout << ExtEff * 100. << "%, SE_mean,width = " << SE << "," << StdDev
         << ")\t";
  }

  // Store the g2 parameters in a vector for later (calculated once per
  // detector)
  g2_params[0] = elYield;
  g2_params[1] = ExtEff;
  g2_params[2] = SE;
  g2_params[3] = g2;
  g2_params[4] = gasGap;
  return g2_params;
}

long double NESTcalc::Factorial(double x) { return tgammal(x + 1.); }

double NESTcalc::nCr(double n, double r) {
  return Factorial(n) / (Factorial(r) * Factorial(n - r));
}

const vector<double> &NESTcalc::GetSpike(int Nph, double dx, double dy,
                                         double dz, double driftSpeed,
                                         double dS_mid,
                                         const vector<double> &oldScint) {
  std::fill(newSpike.begin(), newSpike.end(), 0);

  if (oldScint[7] > SPIKES_MAXM) {
    newSpike[0] = oldScint[4];
    newSpike[1] = oldScint[5];
    return newSpike;
  }
  newSpike[0] = RandomGen::rndm()->rand_zero_trunc_gauss(
      oldScint[6],
      (fdetector->get_sPEres() / 4.) * sqrt(std::abs(oldScint[6])));
  if (XYcorr == 0 || XYcorr == 2) {
    dx = 0.;
    dy = 0.;
  }
  newSpike[1] =
      newSpike[0] / fdetector->FitS1(dx, dy, dz, VDetector::unfold) *
      fdetector->FitS1(
          0., 0., fdetector->get_TopDrift() - dS_mid * fdetector->get_dtCntr(),
          VDetector::unfold);

  return newSpike;  // regular and position-corrected spike counts returned
}

double NESTcalc::SetDensity(double Kelvin, double bara) {
  bool inGas = false;
  double density = GetDensity(Kelvin, bara, inGas, 0);
  fdetector->set_inGas(inGas);

  return density;
}

double NESTcalc::GetDensity(double Kelvin, double bara, bool &inGas,
                            uint64_t evtNum, double molarMass) {
  // currently only for fixed pressure (the saturated vapor pressure); will add
  // pressure dependence later

  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    double density = 0.;
    double VaporP_bar = 0.;
    VaporP_bar = exp(45.973940 - 1464.718291 / Kelvin - 6.539938 * log(Kelvin));
    if (bara < VaporP_bar || inGas) {
      double p_Pa = bara * 1e5;
      density =
          1. /
          (pow(RidealGas * Kelvin, 3.) /
               (p_Pa * pow(RidealGas * Kelvin, 2.) + RealGasA * p_Pa * p_Pa) +
           RealGasB);  // Van der Waals equation, mol/m^3
      density *= molarMass * 1e-6;
      if (bara < VaporP_bar && evtNum == 0)
        cerr << "\nWARNING: ARGON GAS PHASE. IS THAT WHAT YOU WANTED?\n";
      inGas = true;
      return density;
    }
    inGas = false;
    return 1.4;
  }
  // if (MOLAR_MASS > 134.5) //enrichment for 0vBB expt (~0.8 Xe-136)
  // return 3.0305; // ±0.0077 g/cm^3, EXO-200 @167K: arXiv:1908.04128

  if (Kelvin < 161.40 &&
      ValidityTests::nearlyEqual(ATOM_NUM, 54.)) {  // solid Xenon
    cerr << "\nWARNING: SOLID PHASE. IS THAT WHAT YOU WANTED?\n";
    return 3.41;  // from Yoo at 157K
    // other sources say 3.1 (Wikipedia, 'minimum') and 3.640g/mL at an unknown
    // temperature
  }

  double VaporP_bar;  // we will calculate using NIST
  if (Kelvin < 289.7) {
    if (ValidityTests::nearlyEqual(ATOM_NUM, 54.))
      VaporP_bar = pow(10., 4.0519 - 667.16 / Kelvin);
    else {
      VaporP_bar = 1.;
    }
  } else {
    VaporP_bar = DBL_MAX;
  }
  if (bara < VaporP_bar || inGas) {
    double p_Pa = bara * 1e5;
    double density =
        1. /
        (pow(RidealGas * Kelvin, 3.) /
             (p_Pa * pow(RidealGas * Kelvin, 2.) + RealGasA * p_Pa * p_Pa) +
         RealGasB);  // Van der Waals equation, mol/m^3
    density *= molarMass * 1e-6;
    if (bara < VaporP_bar && evtNum == 0)
      cerr << "\nWARNING: GAS PHASE. IS THAT WHAT YOU WANTED?\n";
    inGas = true;
    return density;  // in g/cm^3
  }
  inGas = false;
  return 2.9970938084691329E+02 * exp(-8.2598864714323525E-02 * Kelvin) -
         1.8801286589442915E+06 * exp(-pow((Kelvin - 4.0820251276172212E+02) /
                                               2.7863170223154846E+01,
                                           2.)) -
         5.4964506351743057E+03 * exp(-pow((Kelvin - 6.3688597345042672E+02) /
                                               1.1225818853661815E+02,
                                           2.)) +
         8.3450538370682614E+02 * exp(-pow((Kelvin + 4.8840568924597342E+01) /
                                               7.3804147172071107E+03,
                                           2.)) -
         8.3086310405942265E+02;  // in grams per cubic centimeter based on
                                  // zunzun fit to NIST data; will add gas later
}

double NESTcalc::SetDriftVelocity(double Kelvin, double Density,
                                  double eField, double Bar) {
  return GetDriftVelocity(Kelvin, Density, eField, fdetector->get_inGas(), Bar);
}

double NESTcalc::GetDriftVelocity(double Kelvin, double Density, double eField,
                                  bool inGas, double Bar) {
  if (inGas)
    return GetDriftVelocity_MagBoltz(Kelvin, Density, eField, Bar);
  else {
    return GetDriftVelocity_Liquid(Kelvin, eField, Density, Bar);
  }
}

double NESTcalc::GetDriftVelocity_Liquid(double Kelvin, double eField, double Density,
                                         double Bar, short int StdDev) {
  // for liquid and solid only. Density and purity dependencies to be
  // added in the future.

  double speed =
      0.0;  // returns drift speed in mm/usec. based on Fig. 14 arXiv:1712.08607
  int i, j;
  double vi, vf, slope, Ti, Tf, offset;

  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // replace eventually with Kate's work, once T's splined as done for LXe and
    // SXe
    /*x_nest is field in kV/cm:
    Liquid:
    y_nest_85 = 2.553969*(0.929235**(1/x_nest))*x_nest**0.315673 // temperatures
    in Kelvin y_nest_87 = 2.189388*(0.961701**(1/x_nest))*x_nest**0.339414
    y_nest_89 = 2.201489*(0.931080**(1/x_nest))*x_nest**0.320762
    y_nest_94 = 1.984534*(0.936081**(1/x_nest))*x_nest**0.332491
    y_nest_100 = 2.150101*(0.929447**(1/x_nest))*x_nest**0.317973
    y_nest_120 = 1.652059*(0.935714**(1/x_nest))*x_nest**0.329025
    y_nest_130 = 1.273891*(0.965041**(1/x_nest))*x_nest**0.336455
    Solid:
    y_nest_80 = 7.063288*(0.929753**(1/x_nest))*x_nest**0.314640
    y_nest_82 = 5.093097*(0.920459**(1/x_nest))*x_nest**0.458724*/
    double Temperature[8] = {85., 86., 88., 92., 96., 110., 125., 140.};

    if (Kelvin < 84. || Kelvin > 140.) {
      cerr << "\nWARNING: TEMPERATURE OUT OF RANGE (84-140 K) for vD\n";
      cerr << "Using value at closest temp for a drift speed estimate\n";
      Kelvin = (double)NESTcalc::clamp(int(Kelvin), 84, 140);
    }
	//if (Kelvin==89) speed =  2.201489*pow(0.931080,1/(eField/1000))*pow((eField/1000), 0.320762);
   if (Kelvin >= Temperature[0] && Kelvin < Temperature[1])
      speed = exp(0.937729 - 0.0734108 / (eField / 1000) +
                  0.315338 * log(eField / 1000));
    else if (Kelvin >= Temperature[1] && Kelvin < Temperature[2])
      speed = exp(0.80302379 - 0.06694564 / (eField / 1000) +
                  0.331798 * log(eField / 1000));
    else if (Kelvin >= Temperature[2] && Kelvin < Temperature[3])
      speed = exp(0.7795972 - 0.0990952 / (eField / 1000) +
                  0.320876 * log(eField / 1000));
    else if (Kelvin >= Temperature[3] && Kelvin < Temperature[4])
      speed = exp(0.6911897 - 0.092997 / (eField / 1000) +
                  0.3295202 * log(eField / 1000));
    else if (Kelvin >= Temperature[4] && Kelvin < Temperature[5])
      speed = exp(0.76551511 - 0.0731659 / (eField / 1000) +
                  0.317972 * log(eField / 1000));
    else if (Kelvin >= Temperature[5] && Kelvin < Temperature[6])
      speed = exp(0.502022794 - 0.06644517 / (eField / 1000) +
                  0.3290246 * log(eField / 1000));
    else if (Kelvin >= Temperature[6] && Kelvin <= Temperature[7])
      speed = exp(0.24207633 - 0.03558428 / (eField / 1000) +
                  0.33645519 * log(eField / 1000));

    if (speed < 0.) speed = 0.;
    return speed;
  }

  if (StdDev >= 1)
    return 1.83 - 1.83 / (1. + pow(eField / 30., 1.3));  // eF<260V/cm
  if (StdDev >= 0) return 1.7681 - 1.7681 / (1. + pow(eField / 31.683, 1.3237));

  double polyExp[11][7] = {
      {-3.1046, 27.037, -2.1668, 193.27, -4.8024, 646.04, 9.2471},  // 100K
      {-2.7394, 22.760, -1.7775, 222.72, -5.0836, 724.98, 8.7189},  // 120
      {-2.3646, 164.91, -1.6984, 21.473, -4.4752, 1202.2, 7.9744},  // 140
      {-1.8097, 235.65, -1.7621, 36.855, -3.5925, 1356.2, 6.7865},  // 155
      {-1.5000, 37.021, -1.1430, 6.4590, -4.0337, 855.43,
       5.4238},  // 157, merging Miller with Yoo
      {-1.4939, 47.879, 0.12608, 8.9095, -1.3480, 1310.9,
       2.7598},  // 163, merging Miller with Yoo
      {-1.5389, 26.602, -.44589, 196.08, -1.1516, 1810.8, 2.8912},  // 165
      {-1.5000, 28.510, -.21948, 183.49, -1.4320, 1652.9, 2.884},   // 167
      {-1.1781, 49.072, -1.3008, 3438.4, -.14817, 312.12, 2.8049},  // 184
      {1.2466, 85.975, -.88005, 918.57, -3.0085, 27.568, 2.3823},   // 200
      {334.60, 37.556, 0.92211, 345.27, -338.00, 37.346, 1.9834}};  // 230

  double Temperatures[11] = {100., 120., 140., 155., 157., 163.,
                             165., 167., 184., 200., 230.};

  if (Kelvin < 100. || Kelvin > 230.) {
    cerr << "\nWARNING: TEMPERATURE OUT OF RANGE (100-230 K) for vD\n";
    if (Kelvin < 100.) Kelvin = 100.;
    if (Kelvin > 230.) Kelvin = 230.;
    cerr << "Using value at closest temp for a drift speed estimate\n";
  }

  if (Kelvin >= Temperatures[0] && Kelvin < Temperatures[1])
    i = 0;
  else if (Kelvin >= Temperatures[1] && Kelvin < Temperatures[2])
    i = 1;
  else if (Kelvin >= Temperatures[2] && Kelvin < Temperatures[3])
    i = 2;
  else if (Kelvin >= Temperatures[3] && Kelvin < Temperatures[4])
    i = 3;
  else if (Kelvin >= Temperatures[4] && Kelvin < Temperatures[5])
    i = 4;
  else if (Kelvin >= Temperatures[5] && Kelvin < Temperatures[6])
    i = 5;
  else if (Kelvin >= Temperatures[6] && Kelvin < Temperatures[7])
    i = 6;
  else if (Kelvin >= Temperatures[7] && Kelvin < Temperatures[8])
    i = 7;
  else if (Kelvin >= Temperatures[8] && Kelvin < Temperatures[9])
    i = 8;
  else if (Kelvin >= Temperatures[9] && Kelvin <= Temperatures[10])
    i = 9;
  else {
    throw std::runtime_error("ERROR: TEMPERATURE OUT OF RANGE (100-230 K)");
  }

  j = i + 1;
  Ti = Temperatures[i];
  Tf = Temperatures[j];
  // functional form from http://zunzun.com
  vi = polyExp[i][0] * exp(-eField / polyExp[i][1]) +
       polyExp[i][2] * exp(-eField / polyExp[i][3]) +
       polyExp[i][4] * exp(-eField / polyExp[i][5]) + polyExp[i][6];
  vf = polyExp[j][0] * exp(-eField / polyExp[j][1]) +
       polyExp[j][2] * exp(-eField / polyExp[j][3]) +
       polyExp[j][4] * exp(-eField / polyExp[j][5]) + polyExp[j][6];
  if (ValidityTests::nearlyEqual(Kelvin, Ti)) return vi;
  if (ValidityTests::nearlyEqual(Kelvin, Tf)) return vf;
  if (vf < vi) {
    offset = (sqrt((Tf * (vf - vi) - Ti * (vf - vi) - 4.) * (vf - vi)) +
              sqrt(Tf - Ti) * (vf + vi)) /
             (2. * sqrt(Tf - Ti));
    slope = -(sqrt(Tf - Ti) *
                  sqrt((Tf * (vf - vi) - Ti * (vf - vi) - 4.) * (vf - vi)) -
              (Tf + Ti) * (vf - vi)) /
            (2. * (vf - vi));
    speed = 1. / (Kelvin - slope) + offset;
  } else {
    slope = (vf - vi) / (Tf - Ti);
    speed = slope * (Kelvin - Ti) + vi;
  }

  if (speed <= 0.) {
    cerr << "\nWARNING: DRIFT SPEED NON-POSITIVE. Setting to 0.1 mm/us\t"
         << "Line Number ~1950 of NEST.cpp, in function "
            "NESTcalc::GetDriftVelocity_Liquid\t"
         << "Stop bothering Matthew about this, and fix underlying cause in "
            "your code!\n";
    if (eField < 1e2 && eField >= FIELD_MIN) {
      cerr << "FIELD MAY BE TOO LOW. ";
    } else if (eField > 1e4) {
      cerr << "FIELD MAYBE TOO HIGH. ";
    } else {
      cerr << "Something unknown went wrong: are you in a noble element?? ";
    }
    cerr << "EF = " << eField << " V/cm. T = " << Kelvin << " Kelvin" << endl;
    speed = 0.1;
  }
  return speed;  // mm per microsecond
}

double NESTcalc::GetDriftVelocity_MagBoltz(double temperature,
					   double density, double efieldinput, double pressure,
    double molarMass)  // Nichole Barry UCD 2011; R3 & R4 Refit Joseph Lau UCLA 2026
    // R3+R4: LM piecewise (PyBoltz 2018) + Chebyshev deg9 near R3/R4 boundary
{
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // GAr drift velocity: Chebyshev deg 15 (0.02 to 22 Td) + quadratic (>22 Td)
    // Fit to 105 PyBoltz 2018 MC points (2e8 collisions). Combined RMS = 0.74%.
    // Monotonically increasing. Clenshaw recurrence for numerical stability.
    // Joseph Lau UCLA 2026
    molarMass = 39.948;
    density *= NEST_AVO / molarMass;
    double gasdep = efieldinput / density;
    double Td = gasdep * 1.0e17;

    if (Td > 2.196953035004685e+01) {
      // Quadratic fit to 15 PyBoltz 2018 MC points (23 to 160 Td)
      // RMS = 1.00%
      double dTd = Td - 2.196953035004685e+01;
      return -7.526167982793750e-04 * dTd * dTd +
              7.676412612290673e-01 * dTd + 2.039192218977246e+01;
    }

    // Map ln(Td) to Chebyshev domain [-1, 1]
    double u = log(Td);
    double t = 2.0 * (u - (-3.913408949493860e+00)) /
               7.003065458786462e+00 - 1.0;

    // Chebyshev deg 15 coefficients (fit in ln(v_drift) vs ln(Td) space)
    static constexpr double c[16] = {
        1.232665135170256e+00,   // c[0]
        1.302895762518890e+00,   // c[1]
        3.282190686579693e-01,   // c[2]
        1.826012757924152e-01,   // c[3]
        5.313707825283899e-02,   // c[4]
       -3.695347384963019e-02,   // c[5]
       -4.523835429922259e-02,   // c[6]
       -2.135435936079648e-02,   // c[7]
        6.048415001627724e-03,   // c[8]
        1.671628646536734e-02,   // c[9]
        1.000506474463453e-02,   // c[10]
        5.110565921611583e-04,   // c[11]
       -6.487288773395466e-03,   // c[12]
       -9.546413639078079e-03,   // c[13]
       -2.952720852070562e-03,   // c[14]
        4.872318921365352e-03    // c[15]
    };

    // Clenshaw recurrence: evaluates sum c[k]*T_k(t) for k = 0 to 15
    double b2 = 0.0, b1 = 0.0;
    for (int k = 15; k >= 1; --k) {
      double b0 = 2.0 * t * b1 - b2 + c[k];
      b2 = b1;
      b1 = b0;
    }
    double ln_vd = t * b1 - b2 + c[0];
    return exp(ln_vd);  // mm/us
  }
  // R1+R2: unchanged from Nichole Barry UCD 2011 (MagBoltz v8)
  // Gas equation one coefficients (E/N of 1.2E-19 to 3.5E-19)
  density *= NEST_AVO / molarMass;
  double gas1a = 395.50266631436, gas1b = -357384143.004642,
         gas1c = 0.518110447340587;
  // Gas equation two coefficients (E/N of 3.5E-19 to 3.8E-17)
  // Refit to PyBoltz 2018 MC (60 pts, 2e8 collisions, Levenberg-Marquardt)
  double gas2a = -502223.177165246, gas2b = -88704.6037103696,
         gas2c = -4976.27772160615, gas2d = -114.436719565408,
         gas2f = -0.940702077347825, gas2g = 29.9193608036038,
         gas2h = 117.945882910319;
  double edrift = 0., gasdep = efieldinput / density, gas1fix = 0.,
         gas2fix = 0.;

  // Regime 1: E/N < 1.2E-19 V cm^2 (linear)
  if (gasdep < 1.2e-19 && gasdep >= 0.) edrift = 4e22 * gasdep;
  // Regime 2: 1.2E-19 <= E/N < 3.5E-19 (power law)
  if (gasdep < 3.5e-19 && gasdep >= 1.2e-19) {
    gas1fix = gas1b * pow(gasdep, gas1c);
    edrift = gas1a * pow(gasdep, gas1fix);
  }
  // Regimes 3+4: E/N >= 3.5E-19 (LM piecewise + Chebyshev near boundary)
  // The LM piecewise refit has a 4.65% discontinuity at E/N = 3.8 Td
  // (the old R3/R4 boundary). A Chebyshev deg 9 polynomial, fit to the
  // same PyBoltz 2018 MC data, is smooth everywhere and replaces LM in
  // the zone [2.5, 6.0] Td near the boundary. Hermite
  // smooth blending (3x^2 - 2x^3) over 0.5 Td at each edge ensures
  // C1 continuity (zero derivative at both ends of the transition).
  if (gasdep >= 3.5e-19) {
    double Td = gasdep * 1e17;

    // LM piecewise value (R3 log-polynomial or R4 linear)
    double edrift_lm;
    if (gasdep < 3.8e-17) {
      gas2fix = log(gas2g * gasdep);
      edrift_lm = (gas2a + gas2b * gas2fix + gas2c * pow(gas2fix, 2.) +
                gas2d * pow(gas2fix, 3.) + gas2f * pow(gas2fix, 4.)) *
               (gas2h * exp(gasdep));
    } else {
      edrift_lm = 5.80219505881746e+21 * gasdep - 20524.4178957185;
    }
    edrift_lm = std::abs(edrift_lm);

    if (Td < 2.5) {
      edrift = edrift_lm;  // pure LM (R3 bulk)
    } else {
      // Chebyshev deg 9: ln(edrift_cm/s) = P9(t), t in [-1, 1]
      // Fit to PyBoltz 2018 MC points over [0.6, 20] Td
      double u = log(gasdep);
      double t = 2.0 * (u - (-4.195112294025095e+01)) /
                 5.809142990314022e+00 - 1.0;
      double ln_ed = 2.143938128066541e+00;
      ln_ed = ln_ed * t + 2.975900594551476e+00;
      ln_ed = ln_ed * t + (-3.926749202670321e+00);
      ln_ed = ln_ed * t + (-7.411260713318530e+00);
      ln_ed = ln_ed * t + 1.452085040401718e+00;
      ln_ed = ln_ed * t + 5.451306500170360e+00;
      ln_ed = ln_ed * t + 1.223996054502669e+00;
      ln_ed = ln_ed * t + (-3.345597860841636e-01);
      ln_ed = ln_ed * t + 5.703999334643821e-01;
      ln_ed = ln_ed * t + 1.180343118713458e+01;
      double edrift_cheb = exp(ln_ed);

      if (Td < 3.0) {
        // Blend LM -> Chebyshev (Hermite smoothstep)
        double x = (Td - 2.5) / 0.5;
        double alpha = x * x * (3.0 - 2.0 * x);
        edrift = (1.0 - alpha) * edrift_lm + alpha * edrift_cheb;
      } else if (Td < 5.5) {
        edrift = edrift_cheb;  // pure Chebyshev (covers R3/R4 boundary)
      } else if (Td < 6.0) {
        // Blend Chebyshev -> LM (Hermite smoothstep)
        double x = (Td - 5.5) / 0.5;
        double alpha = x * x * (3.0 - 2.0 * x);
        edrift = (1.0 - alpha) * edrift_cheb + alpha * edrift_lm;
      } else {
        edrift = edrift_lm;  // pure LM (R4 high field)
      }
    }
  }
  return std::abs(edrift) * 1e-5;  // from cm/s into mm per microsecond
}

vector<double> NESTcalc::SetDriftVelocity_NonUniform(double rho, double zStep, double kel, double bar,
                                                     double dx, double dy) {
  vector<double> speedTable;
  double driftTime, zz;

  for (double pos_z = 0.0; pos_z < fdetector->get_TopDrift(); pos_z += zStep) {
    driftTime = 0.0;
    for (zz = pos_z; zz < fdetector->get_TopDrift(); zz += zStep) {
      if (pos_z > fdetector->get_gate()) {
        if (!fdetector->get_inGas())
          driftTime +=
              zStep / SetDriftVelocity(kel, rho,
                                       fdetector->get_E_gas() /
				       (EPS_LIQ / std::abs(EPS_GAS)) * 1e3, bar);
        else {
          // if gate == TopDrift properly set, shouldn't happen
          driftTime += zStep / GetDriftVelocity_MagBoltz(kel,
					   rho, fdetector->get_E_gas() * 1e3, bar);
        }
      } else {
        driftTime +=
            zStep /
            SetDriftVelocity(
                kel, rho,
                fdetector->FitEF(dx, dy,
                                 zz), bar);  // update x and y if you want 3-D fields
      }
    }

    speedTable.emplace_back((zz - pos_z) / driftTime);  // uses highest zz
  }

  return speedTable;
}

vector<double> NESTcalc::xyResolution(double xPos_mm, double yPos_mm,
                                      double A_top) {
  vector<double> xySmeared(2);
  A_top *= 1. - fdetector->FitTBA(xPos_mm, yPos_mm,
                                  fdetector->get_TopDrift() / 2.)[1];

  double rad = sqrt(pow(xPos_mm, 2.) + pow(yPos_mm, 2.));
  double kappa = fdetector->get_PosResBase();
    //+ exp(fdetector->get_PosResExp() * rad);  // arXiv:1710.02752
  double sigmaR = kappa / sqrt(A_top);  // ibid. But only stat; add syst (~3mm)
  sigmaR = sqrt(sigmaR * sigmaR +
                fdetector->get_PosResFlat() * fdetector->get_PosResFlat());
  // σ_vertex^2 = ((r_vertex/r_S2)*σ_(x,y))^2 + σ_sys^2

  double phi = two_PI * RandomGen::rndm()->rand_uniform();
  sigmaR = std::abs(RandomGen::rndm()->rand_gauss(0.0, sigmaR, false));
  double sigmaX = sigmaR * cos(phi);
  double sigmaY = sigmaR * sin(phi);

  if (sigmaR > 1e2 || std::isnan(sigmaR) || sigmaR < 0. ||
      std::abs(sigmaX) > 1e2 || std::abs(sigmaY) > 1e2) {
    if (A_top >
        40.) {  // roughly three S2 e-'s in most detectors (or ~1.5 in LZ)
      cerr << "WARNING: your pos res is worse than 10 cm or negative. Is that "
              "correct?!"
           << endl;
      cerr << "Setting resolution to perfect, for the current event." << endl;
      sigmaX = 0.;
      sigmaY = 0.;
    }  // this is only a problem if the area is large and the res is still bad
  }

  xySmeared[0] = xPos_mm + sigmaX;
  xySmeared[1] = yPos_mm + sigmaY;

  return xySmeared;  // new X and Y position in mm with empirical smearing. LUX
                     // Run03 example
}

double NESTcalc::PhotonEnergy(bool s2Flag, bool state, double tempK) {
  double wavelength, E_keV;  // wavelength is in nanometers

  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // liquid Argon
    if (state) return RandomGen::rndm()->rand_zero_trunc_gauss(9.7, 0.2);
    return RandomGen::rndm()->rand_zero_trunc_gauss(9.69, 0.22);
  }

  if (!state)  // liquid or solid
    wavelength = RandomGen::rndm()->rand_zero_trunc_gauss(
        178., 14. / 2.355);  // taken from Jortner JchPh 42 '65
  else {                     // gas
    wavelength = RandomGen::rndm()->rand_zero_trunc_gauss(
        175., 5.);  // G4S1Light, probably Doke
  }
  if (s2Flag) {
    // S2 different from ordinary gas (or just measurement error?)
    if (tempK < 200.)  // cold gas
      wavelength = RandomGen::rndm()->rand_zero_trunc_gauss(
          179., 5.);  // source is G4S2Light.cc from the old NEST
    else {
      wavelength = RandomGen::rndm()->rand_zero_trunc_gauss(174., 5.);  // ditto
    }
  }

  E_keV = 1240e-3 / wavelength;  // h*c in keV-nm divided by lambda in nm
  if (E_keV > W_SCINT)
    E_keV = W_SCINT;  // don't go so high breaks G4. Gauss in lambda -> non-G in
  // E, high tail

  return E_keV * 1000.;  // convert from keV into eV. Eventually add full T, P
                         // dependence
}

double NESTcalc::CalcElectronLET(double E, int Z, bool CSDA) {
  double LET;

  if (!CSDA) {  // total stopping power directly from ESTAR (radiative +
                // collision)
    if (ValidityTests::nearlyEqual(ATOM_NUM,
                                   54.))  // loglog poly fit to 1-3e3keV
      LET = 1.4555 + 0.11493 * log10(E) - 1.2364 * pow(log10(E), 2.) +
            1.3677 * pow(log10(E), 3.) - 1.1539 * pow(log10(E), 4.) +
            0.69658 * pow(log10(E), 5.) - 0.28706 * pow(log10(E), 6.) +
            0.077169 * pow(log10(E), 7.) - 0.011957 * pow(log10(E), 8.) +
            0.00079395 * pow(log10(E), 9.);
    else  // ditto(ARGON)
      LET = 1.8106 - 0.45086 * log10(E) - .33151 * pow(log10(E), 2.) +
            .25916 * pow(log10(E), 3.) - 0.2051 * pow(log10(E), 4.) +
            0.15279 * pow(log10(E), 5.) - .084659 * pow(log10(E), 6.) +
            0.030441 * pow(log10(E), 7.) - .0058953 * pow(log10(E), 8.) +
            0.00045633 * pow(log10(E), 9.);
    LET = pow(10., LET);
    if (std::isnan(LET) || LET <= 1.) LET = 1e2;
    return LET;
  }

  // use a 9th-order polynomial spline to online CSDA data (still NIST's ESTAR)
  if (ValidityTests::nearlyEqual(ATOM_NUM, 54.)) {
    if (E >= 1.)
      LET = 58.482 - 61.183 * log10(E) + 19.749 * pow(log10(E), 2) +
            2.3101 * pow(log10(E), 3) - 3.3469 * pow(log10(E), 4) +
            0.96788 * pow(log10(E), 5) - 0.12619 * pow(log10(E), 6) +
            0.0065108 * pow(log10(E), 7);
    // at energies <1 keV, use a different spline, determined manually by
    // generating sub-keV electrons in Geant4 and looking at their ranges, since
    // ESTAR does not go this low (4.9.4)
    else if (E > 0. && E < 1.) {
      LET = 6.9463 + 815.98 * E - 4828 * pow(E, 2) + 17079 * pow(E, 3) -
            36394 * pow(E, 4) + 44553 * pow(E, 5) - 28659 * pow(E, 6) +
            7483.8 * pow(E, 7);
    } else {
      LET = 0.;
    }
  } else {
    // replace with Justin and Prof. Mooney's work
    if (E >= 1.)
      LET = 116.70 - 162.97 * log10(E) + 99.361 * pow(log10(E), 2) -
            33.405 * pow(log10(E), 3) + 6.5069 * pow(log10(E), 4) -
            0.69334 * pow(log10(E), 5) + .031563 * pow(log10(E), 6);
    else if (E > 0. && E < 1.) {
      LET = 100.;
    } else {
      LET = 0.;
    }
  }

  return LET;
}

NESTcalc::Wvalue NESTcalc::WorkFunction(double density, double MolarMass,
                                        bool OldW13eV) {
  double alpha, Wq_eV;
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.)) {
    // Liquid argon
    alpha = 0.21;
    Wq_eV = 1000. / 51.9;  // 23.6/1.21; // ~19.2-5 eV
    return Wvalue{.Wq_eV = Wq_eV, .alpha = alpha};
  }
  alpha = 0.067366 + density * 0.039693;
  /*double xi_se = 9./(1.+pow(density/2.,2.));
  double I_ion = 9.+(12.13-9.)/(1.+pow(density/2.953,65.));
  double I_exc = I_ion / 1.46;
  double Wq_eV = I_exc*(alpha/(1.+alpha))+I_ion/(1.+alpha)
  +xi_se/(1.+alpha);*/
  double eDensity = (density / MolarMass) * NEST_AVO * ATOM_NUM;
  Wq_eV = 18.7263 - 1.01e-23 * eDensity;
  if (OldW13eV) Wq_eV *= ZurichEXOW;              // EXO
  return Wvalue{.Wq_eV = Wq_eV, .alpha = alpha};  // W and Nex/Ni together
}

double NESTcalc::NexONi(double energy, double density) {
  if (ValidityTests::nearlyEqual(ATOM_NUM, 18.))
    return 0.21;  // https://arxiv.org/pdf/1903.05815.pdf
  Wvalue wvalue = WorkFunction(density, fdetector->get_molarMass(),
                               fdetector->get_OldW13eV());
  double alpha = wvalue.alpha;
  return alpha * erf(0.05 * energy);
}

// This function returns the transverse diffusion coefficient in liquid. It
// allows a user to select whether they use the canonical NEST model, or a model
// modified to accommodate higher field values (from Boyle et al., 2016,
// arXiv:1603.04157v1)
double NESTcalc::GetDiffTran_Liquid(
    double dfield, bool highFieldModel, double Kelvin, double Bar, double Density,
    int Z)  // for gas: look for Diff_Tran_Gas above
{
  double output;

  if (Z == 18) {
    // G4S2Light.cc from LUXSim
    double nDensity = NEST_AVO * DENSITY / 40.;  // 1 over cm^3
    return  93.342 * pow(dfield / nDensity, 0.041322);
  }

  // Use the standard NEST parametrization
  if (!highFieldModel) {
    output = 37.368 * pow(dfield, .093452) *
             exp(-8.1651e-5 * dfield);  // arXiv:1609.04467 (EXO-200)
  }
  // Use the Boyle model, which is drastically different at high (>5kV/cm)
  // fields. Note here that the Boyle model is only at one temperature First
  // double in pair is field, second is DT
  else {
    const std::vector<std::pair<double, double> > BoyleModelDT =
        GetBoyleModelDT();
    output = interpolateFunction(BoyleModelDT, dfield, true);
    if (output == 0)
      cerr << "Looks like your desired drift field, " << dfield
           << ", may be either too low or too high to interpolate a DT. "
              "Returning DT=0.\n";
  }
  return output;
}

// This function returns the longitudinal diffusion coefficient in liquid. It
// allows a user to select whether they use the canonical NEST model, or a model
// modified to accommodate higher field values (from Boyle et al., 2016,
// arXiv:1603.04157v1)
double NESTcalc::GetDiffLong_Liquid(
    double dfield, bool highFieldModel, double Kelvin, double Bar, double Density, int Z,
    short int StdDev)  // for gas: look@ Diff_Long_Gas above
{
  double output;

  if (Z == 18) {
    output = 0.63*(-0.0014*dfield+6.98);
    return output;  
  }

  // Use the standard NEST parameterization DiffLong=m1*f^(-m2)+m3*exp(-f/m4)
  if (!highFieldModel) {  // temperature dependence possible: D_L up as T down?
    if (StdDev >= 1)
      output = 60. * pow(dfield, -0.16558) + 462. * exp(-dfield / 23.922);
    // high D_L model (Njoya 2020) 60+/-49, -0.16558+/-0.13347, 462+/-126, 23.922+/-4.8931 (touches the -1-sigma errors)
    else if (StdDev >= 0 && StdDev < 1)
      output = 57.381 * pow(dfield, -0.22221) + 127.27 * exp(-dfield / 32.821);
    // fit to Aprile & Doke rev & arXiv:1102.2865 (Peter: XENON10/100); plus, LUX Run03 (181V/cm) & 1911.11580. Agrees with arXiv:2303.13963 (Yanina Biondi)
    else
      output = 66.35 * pow(dfield, -0.24855) + 36.85 * exp(-dfield / 35.661);
    // low D_L model (LZ 2023, Dan Hunt) 66.35+/-6.29, -0.24855+/-0.016508, 36.85+/-2.37, 35.661+/-2.2038 (low drift fields, double digits)
  }
  // Use the Boyle model, which is drastically different at high (>5kV/cm)
  // fields. Note here that the Boyle model is only at one temperature. First
  // double in pair is field, second is DL
  else {
    const std::vector<std::pair<double, double> > BoyleModelDL =
        GetBoyleModelDL();
    output = interpolateFunction(BoyleModelDL, dfield, true);
    if (output == 0)
      cerr << "Looks like your desired drift field may be either too low or "
              "too high to interpolate a DL Returning DL=0.\n";
  }
  return output;
}

// Simple function for interpolating
double NESTcalc::interpolateFunction(
    const std::vector<std::pair<double, double> > &func, double x,
    bool isLogLog) {
  // Linear interpolation
  if (!isLogLog) {
    double y_desired = 0;
    for (int iP = 0; iP < func.size() - 1; ++iP) {
      double x1 = func[iP].first;
      double x2 = func[iP + 1].first;
      if (x1 < x && x2 >= x) {
        double y1 = func[iP].second;
        double y2 = func[iP + 1].second;
        double slope = (y2 - y1) / (x2 - x1);
        y_desired = y1 + (slope * (x - x1));
        break;
      }
    }
    return y_desired;
  }

  // Linear interpolation on a log-log scale (more accurate at high fields,
  // where points are far apart on a linear scale)
  else {
    double y_desired = 0;
    for (int iP = 0; iP < func.size() - 1; ++iP) {
      double logx1 = log10(func[iP].first);
      double logx2 = log10(func[iP + 1].first);
      if (logx1 < log10(x) && logx2 > log10(x)) {
        double logy1 = log10(func[iP].second);
        double logy2 = log10(func[iP + 1].second);
        double slope = (logy2 - logy1) / (logx2 - logx1);
        double logy_desired = logy1 + slope * (log10(x) - logx1);
        y_desired = pow(10, logy_desired);
        break;
      }
    }
    return y_desired;
  }
}

// Organized nicely to just input the Boyle Model's curve data. Using vectors
// and pairs so all of the size accounting is done nicely downstream without
// having to pass container sizes around.
std::vector<std::pair<double, double> > NESTcalc::GetBoyleModelDT() {
  std::vector<std::pair<double, double> > output;
  const int nPts = 25;
  constexpr double modelDT[nPts][2] = {
      {14.6236, 24.674},  {24.5646, 26.4954}, {36.675, 29.2043},
      {53.4802, 32.6845}, {74.3939, 37.9944}, {111.071, 45.3424},
      {173.835, 58.2226}, {306.106, 74.6236}, {467.921, 89.2124},
      {749.809, 96.9913}, {1093.38, 98.4549}, {1711.25, 97.3852},
      {2615.85, 92.5493}, {3998.65, 85.4419}, {6258.24, 78.2405},
      {9794.71, 67.7294}, {16453.1, 58.544},  {27637.8, 50.3599},
      {38445.7, 48.5424}, {49828.3, 43.4695}, {70967.5, 36.8038},
      {98719.8, 32.7631}, {127948, 29.5377},  {169785, 27.4412},
      {220053, 27.9686}};
  for (auto &iP : modelDT) {
    output.emplace_back(iP[0], iP[1]);
  }
  return output;
}

// Organized nicely to just input the Boyle Model's curve data. Using vectors
// and pairs so all of the size accounting is done nicely downstream without
// having to pass container sizes around. Returns cm^2/s
std::vector<std::pair<double, double> > NESTcalc::GetBoyleModelDL() {
  std::vector<std::pair<double, double> > output;
  const int nPts = 25;
  constexpr double modelDL[nPts][2] = {
      {14.6236, 22.2977},  {24.5646, 22.4238},  {36.675, 22.933},
      {53.4802, 23.4595},  {74.3939, 25.4994},  {111.071, 29.4632},
      {173.835, 33.9251},  {306.106, 38.1019},  {467.921, 37.2352},
      {749.809, 31.8425},  {1093.38, 25.495},   {1711.25, 18.3343},
      {2615.85, 12.6461},  {3998.65, 8.51594},  {6258.24, 5.23814},
      {9794.71, 3.01815},  {16453.1, 1.58294},  {27637.8, 0.779995},
      {38445.7, 0.525689}, {49828.3, 0.364016}, {70967.5, 0.228694},
      {98719.8, 0.148206}, {127948, 0.116139},  {169785, 0.0957632},
      {220053, 0.0900259}};
  for (auto &iP : modelDL) {
    output.emplace_back(iP[0], iP[1]);
  }
  return output;
}

constexpr int NESTcalc::clamp(int v, const int lo, const int hi) {
  if (v < lo) v = lo;
  if (v > hi) v = hi;
  return v;
}
